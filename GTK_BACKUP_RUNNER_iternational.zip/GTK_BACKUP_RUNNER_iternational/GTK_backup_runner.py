#!/usr/bin/env python3
import gi
import subprocess
import os
import fnmatch
import time
from threading import Thread
import queue
from datetime import datetime
from pathlib import Path
gi.require_version("Gtk", "4.0")
gi.require_version("Gdk", "4.0")
from gi.repository import Gtk, Gio, Gdk, GLib
import zipfile
import shutil
import configparser
import json
import math
import gettext
import locale
import sys

# Default translation function (will be replaced if translations are available)
_ = lambda x: x

# Configuration
domain = "gtkbackuprunner"
#LOCALE_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'locale')
LOCALE_DIR = "/usr/share/locale"

class BackupApp(Gtk.ApplicationWindow):
    def __init__(self, app, lang=None):
        # Initialize translations before anything else
        self._init_translations(lang)
        
        super().__init__(application=app, title=_("GTK Backup Runner"))
        self.apply_consistent_styling(self)
        self.set_default_size(800, 600)

        # Store current language (use system default if none specified)
        self.current_language = lang if lang else self._get_system_language()

        # Language options
        self.languages = {
            "en": "English",
            "zh_TW": "繁體中文",
            "zh_CN": "简体中文",
            "ja": "日本語",
            "ko": "한국어",
            "es": "Español", 
            "fr": "Français",
            "de": "Deutsch",
            "th": "ไทย", 
            "id": "Bahasa Indonesia"            
        }

        # Configuration
        self.config_dir = os.path.join(os.path.expanduser("~"), ".config")
        self.config_path = os.path.join(self.config_dir, "gtk-backup-runner.conf")
        self.phases = {}
        self.load_config()

        # Main vertical box
        vbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        vbox.set_margin_top(20)
        vbox.set_margin_bottom(20)
        vbox.set_margin_start(20)
        vbox.set_margin_end(20)

        # Language selection
        lang_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        lang_label = Gtk.Label(label=_("Language:"))
        
        # Create model and map for language selection
        self.lang_model = Gtk.StringList()
        self.lang_map = []
        
        # Populate with supported languages
        supported_langs = self._get_supported_locales()
        for code, name in self.languages.items():
            if code in supported_langs:
                self.lang_model.append(name)
                self.lang_map.append(code)
        
        # Create DropDown and set current selection to match actual language
        self.lang_combo = Gtk.DropDown(model=self.lang_model)
        try:
            current_idx = self.lang_map.index(self.current_language)
            self.lang_combo.set_selected(current_idx)
        except ValueError:
            # Fallback to English if current language not available
            try:
                self.lang_combo.set_selected(self.lang_map.index("en"))
            except:
                self.lang_combo.set_selected(0)
        
        self.lang_combo.connect("notify::selected", self.on_language_changed)
        
        lang_box.append(lang_label)
        lang_box.append(self.lang_combo)
        vbox.append(lang_box)

        # Title label
        title_label = Gtk.Label(label=_("File Backup Helper - Backup multiple directories based on configuration"))
        vbox.append(title_label)

        # Setup button
        setup_button = Gtk.Button(label=_("Configure Backup Tasks"))
        setup_button.connect("clicked", self.show_setup_dialog)
        vbox.append(setup_button)

        # Date picker button
        self.date_button = Gtk.Button(label=_("Select Modified Files Start Date"))
        self.date_button.connect("clicked", self.open_date_picker)
        vbox.append(self.date_button)

        # Selected date display
        self.date_label = Gtk.Label(label=_("Selected date: None"))
        vbox.append(self.date_label)

        # Backup button
        self.backup_button = Gtk.Button(label=_("Run Backup"))
        self.backup_button.connect("clicked", self.run_backup)
        vbox.append(self.backup_button)

        # Progress bar
        self.progress_bar = Gtk.ProgressBar()
        vbox.append(self.progress_bar)

        # Output console
        self.output_view = Gtk.TextView()
        self.output_view.set_editable(False)
        self.output_view.set_wrap_mode(Gtk.WrapMode.WORD)
        self.output_buffer = self.output_view.get_buffer()

        scroll = Gtk.ScrolledWindow()
        scroll.set_child(self.output_view)
        scroll.set_min_content_height(300)
        vbox.append(scroll)

        self.set_child(vbox)

        # Progress tracking
        self.progress_queue = queue.Queue()
        self.progress_updater_running = False
        self.total_files = 0
        self.processed_files = 0
        self.current_phase = ""
        self.selected_date = None
        # Show welcome message (after UI is ready)
        GLib.idle_add(self._show_welcome_message)
        
        
    def _show_welcome_message(self):
        """Thread-safe welcome message display"""
        if not hasattr(self, "_welcome_shown"):
            msg = _(
                "This program can back up files modified or created ON or AFTER "
                "the specified date.\n"
                "Multiple directories can be configured for batch backup and compression.\n"
                "\n"
                "Usage:\n"
                "1. Configure backup tasks\n"
                "2. Select the starting date\n"
                "3. Execute backup\n"
                "\n"
                "Licensed under LGPL\n"
                "This program comes with ABSOLUTELY NO WARRANTY."
            )
            
            self.append_output(msg)
            self._welcome_shown = True
        return False  # Important for GLib.idle_add 
               

    def _init_translations(self, lang=None):
        """Thread-safe translation initialization"""
        gettext.textdomain('gtkbackuprunner')  # <-- THIS IS CRITICAL
        gettext.bindtextdomain('gtkbackuprunner', LOCALE_DIR)
        try:
            if lang:
                os.environ['LANGUAGE'] = lang
                os.environ['LC_ALL'] = f"{lang}.UTF-8"
            
            # Install for both main thread and future threads
            translation = gettext.translation(
                'gtkbackuprunner',
                LOCALE_DIR,
                languages=[lang] if lang else None,
                fallback=True
            )
            translation.install()  # This sets _ globally
            global _
            _ = translation.gettext  # Ensure we use the right _
            
            # For thread safety
            if not callable(_):
                _ = lambda x: x
        except Exception as e:
            print(f"Translation error: {e}")
            _ = lambda x: x
            
            




            
            

    def _get_system_language(self):
        """Get system language in a robust way"""
        try:
            # Check environment variables first
            for var in ['LANGUAGE', 'LC_ALL', 'LANG', 'LC_MESSAGES']:
                lang = os.environ.get(var)
                if lang:
                    # Clean up language string (e.g., 'zh_TW.UTF-8' -> 'zh_TW')
                    lang = lang.split('.')[0]
                    if '_' in lang:
                        return lang
                    elif lang == 'zh':
                        return 'zh_TW'  # Default to Traditional Chinese for 'zh'
            
            # Fallback to locale.getlocale()
            lang = locale.getlocale()[0]
            if lang:
                return lang.split('.')[0]
            
        except Exception as e:
            print(f"Error detecting system language: {e}")
        
        return "en"  # Ultimate fallback

    def _get_supported_locales(self):
        """Check which locales are actually available"""
        supported = ['en']  # English is always available
        current_locale = locale.getlocale()
        
        for lang in self.languages:
            if lang == 'en':
                continue
            try:
                # Try setting the locale
                locale.setlocale(locale.LC_ALL, f"{lang}.UTF-8")
                supported.append(lang)
            except locale.Error:
                try:
                    # Try alternative format
                    locale.setlocale(locale.LC_ALL, f"{lang}.utf8")
                    supported.append(lang)
                except locale.Error:
                    continue
            finally:
                # Restore original locale
                try:
                    locale.setlocale(locale.LC_ALL, current_locale)
                except:
                    locale.setlocale(locale.LC_ALL, 'C')
        
        return supported

    def load_config(self):
        """Load configuration from file"""
        if not os.path.exists(self.config_path):
            self.phases = {
                "example": {
                    "name": _("Example Backup"),
                    "source": self.get_documents_dir(),
                    "target": self.get_download_dir(),
                    "file_patterns": "*.docx, *.xlsx, *.pptx, *.odt, *.ods, *.odp, *.txt, *.csv, *.pdf",
                    "exclude_patterns": "*.exe"
                }
            }
            self.save_config()
            #return
        
        config = configparser.ConfigParser()
        config.read(self.config_path)
        
        self.phases = {}
        for section in config.sections():
            self.phases[section] = {
                "name": config.get(section, "name", fallback=section),
                "source": config.get(section, "source"),
                "target": config.get(section, "target", fallback=""),
                "file_patterns": config.get(section, "file_patterns", fallback="*"),
                "exclude_patterns": config.get(section, "exclude_patterns", fallback="")
            }

    def remove_phase(self, frame, phase_id):
        """Remove a backup phase from both UI and configuration"""
        if phase_id in self.phases:
            del self.phases[phase_id]
        self.phases_container.remove(frame)
        self.phases_container.queue_draw()

    def add_new_phase_ui(self, button):
        """Add UI for a new phase"""
        phase_id = f"phase_{len(self.phases) + 1}"
        self.phases[phase_id] = {
            "name": _("New Backup Phase"),
            "source": "",
            "target": "",
            "file_patterns": "*",
            "exclude_patterns": ""
        }
        self.add_phase_ui(phase_id, self.phases[phase_id])

    def save_config_from_dialog(self, dialog):
        """Save configuration from dialog inputs"""
        for phase_id, phase in list(self.phases.items()):
            if "ui" in phase:
                phase["name"] = phase["ui"]["name"].get_text()
                phase["source"] = phase["ui"]["source"].get_text()
                phase["target"] = phase["ui"]["target"].get_text()
                phase["file_patterns"] = phase["ui"]["patterns"].get_text()
                phase["exclude_patterns"] = phase["ui"]["exclude"].get_text()
                
                del phase["ui"]
                
                if not phase["name"] and not phase["source"]:
                    del self.phases[phase_id]
        
        self.save_config()
        dialog.close()
        self.append_output(_("Configuration saved\n"))

    def save_config(self):
        """Save configuration to file"""
        os.makedirs(self.config_dir, exist_ok=True)
        
        config = configparser.ConfigParser()
        
        for phase_id, phase in self.phases.items():
            clean_id = phase["name"].strip().replace(" ", "_")
            if not clean_id:
                clean_id = f"phase_{phase_id}"
            
            config[clean_id] = {
                "name": phase["name"],
                "source": phase["source"],
                "target": phase["target"],
                "file_patterns": phase["file_patterns"],
                "exclude_patterns": phase["exclude_patterns"]
            }
        
        with open(self.config_path, 'w', encoding='utf-8') as configfile:
            config.write(configfile)

    def select_directory(self, entry_widget):
        """Modern GTK4 directory selection with proper async handling"""
        dialog = Gtk.FileDialog(
            title=_("Select Directory"),
            modal=True
        )
        
        current_path = entry_widget.get_text()
        if current_path and os.path.exists(current_path):
            dialog.set_initial_folder(Gio.File.new_for_path(current_path))
        
        def on_finish(dialog, result):
            try:
                file = dialog.select_folder_finish(result)
                if file:
                    entry_widget.set_text(file.get_path())
            except GLib.Error as err:
                print(f"Error selecting folder: {err}")
        
        dialog.select_folder(
            parent=self,
            cancellable=None,
            callback=on_finish
        )

    def show_setup_dialog(self, button):
        """Show the backup configuration dialog"""
        dialog = Gtk.Dialog(transient_for=self, modal=True)                
        self.apply_consistent_styling(dialog)
        dialog.set_title(_("Configure Backup Tasks"))
        dialog.set_default_size(700, 650)
        
        header = Gtk.HeaderBar()
        dialog.set_titlebar(header)
        
        cancel_btn = Gtk.Button(label=_("Cancel"))
        cancel_btn.connect("clicked", lambda *_: dialog.close())
        header.pack_start(cancel_btn)
        
        save_btn = Gtk.Button(label=_("Save Settings"))
        save_btn.add_css_class("suggested-action")
        save_btn.connect("clicked", lambda b: self.save_config_from_dialog(dialog))
        header.pack_end(save_btn)
        
        new_btn = Gtk.Button(label=_("Add Phase"))
        new_btn.connect("clicked", self.add_new_phase_ui)
        header.pack_end(new_btn)
        
        main_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        main_box.set_margin_top(10)
        main_box.set_margin_bottom(10)
        main_box.set_margin_start(10)
        main_box.set_margin_end(10)
        
        scrolled = Gtk.ScrolledWindow()
        scrolled.set_min_content_height(550)
        scrolled.set_policy(
            Gtk.PolicyType.NEVER,
            Gtk.PolicyType.AUTOMATIC
        )
        
        css_provider = Gtk.CssProvider()
        css_provider.load_from_data(b"""
            scrolledwindow {
                border: 1px solid #ddd;
                border-radius: 5px;
                background: #000;
            }
            .phase-frame {
                min-height: 300px;
                border-radius: 8px;
                border: 1px solid #aaa;
                background: #444;
                padding: 15px;
                margin: 10px;
            }
            .destructive-btn {
                background: #a00;
                color: #eef;
                margin-top: 15px;
            }
        """)
        
        display = Gdk.Display.get_default()
        Gtk.StyleContext.add_provider_for_display(
            display,
            css_provider,
            Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION
        )
        
        self.phases_container = Gtk.Box(
            orientation=Gtk.Orientation.VERTICAL,
            spacing=15,
            hexpand=True,
            vexpand=True
        )
        self.phases_container.set_margin_top(10)
        self.phases_container.set_margin_bottom(10)
        self.phases_container.set_margin_start(10)
        self.phases_container.set_margin_end(10)
        
        for phase_id, phase in self.phases.items():
            self.add_phase_ui(phase_id, phase)
        
        scrolled.set_child(self.phases_container)
        main_box.append(scrolled)
        dialog.set_child(main_box)
        dialog.present()

    def add_phase_ui(self, phase_id, phase):
        """Add UI controls for a backup phase"""
        frame = Gtk.Frame()
        frame.add_css_class("phase-frame")
        
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        box.set_margin_top(10)
        box.set_margin_bottom(10)
        box.set_margin_start(10)
        box.set_margin_end(10)
        
        # Phase name
        name_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        name_label = Gtk.Label(label=_("Phase Name:"), width_request=100, xalign=0)
        name_entry = Gtk.Entry()
        name_entry.set_text(phase["name"])
        name_entry.set_hexpand(True)
        name_entry.set_size_request(-1, 40)
        name_box.append(name_label)
        name_box.append(name_entry)
        box.append(name_box)

        # Source directory
        source_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        source_label = Gtk.Label(label=_("Source Directory:"), width_request=100, xalign=0)
        source_entry = Gtk.Entry()
        source_entry.set_text(phase["source"])
        source_entry.set_hexpand(True)
        source_entry.set_size_request(-1, 40)
        source_button = Gtk.Button(label=_("Browse..."))
        source_button.set_size_request(90, 40)
        source_button.connect("clicked", lambda b, e=source_entry: self.select_directory(e))
        source_box.append(source_label)
        source_box.append(source_entry)
        source_box.append(source_button)
        box.append(source_box)

        # Target directory
        target_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        target_label = Gtk.Label(label=_("Target Directory:"), width_request=100, xalign=0)
        target_entry = Gtk.Entry()
        target_entry.set_text(phase["target"])
        target_entry.set_hexpand(True)
        target_entry.set_size_request(-1, 40)
        target_button = Gtk.Button(label=_("Browse..."))
        target_button.set_size_request(90, 40)
        target_button.connect("clicked", lambda b, e=target_entry: self.select_directory(e))
        target_box.append(target_label)
        target_box.append(target_entry)
        target_box.append(target_button)
        box.append(target_box)

        # File patterns
        patterns_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        patterns_label = Gtk.Label(label=_("File Patterns:"), width_request=100, xalign=0)
        patterns_entry = Gtk.Entry()
        patterns_entry.set_text(phase["file_patterns"])
        patterns_entry.set_hexpand(True)
        patterns_entry.set_size_request(-1, 40)
        patterns_label_tip = Gtk.Label(label=_("(e.g., *.php,*.js,*.css)"))
        patterns_box.append(patterns_label)
        patterns_box.append(patterns_entry)
        patterns_box.append(patterns_label_tip)
        box.append(patterns_box)

        # Exclude patterns
        exclude_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        exclude_label = Gtk.Label(label=_("Exclude Patterns:"), width_request=100, xalign=0)
        exclude_entry = Gtk.Entry()
        exclude_entry.set_text(phase["exclude_patterns"])
        exclude_entry.set_hexpand(True)
        exclude_entry.set_size_request(-1, 40)
        exclude_label_tip = Gtk.Label(label=_("(e.g., *.tmp,*.bak,*.log)"))
        exclude_box.append(exclude_label)
        exclude_box.append(exclude_entry)
        exclude_box.append(exclude_label_tip)
        box.append(exclude_box)

        # Remove button
        remove_button = Gtk.Button(label=_("Remove Phase"))
        remove_button.set_size_request(-1, 40)
        remove_button.add_css_class("destructive-btn")
        remove_button.connect("clicked", lambda b, f=frame, pid=phase_id: self.remove_phase(f, pid))
        box.append(remove_button)

        frame.set_child(box)
        self.phases_container.append(frame)
        
        self.phases[phase_id]["ui"] = {
            "name": name_entry,
            "source": source_entry,
            "target": target_entry,
            "patterns": patterns_entry,
            "exclude": exclude_entry
        }

    def apply_consistent_styling(self, widget):
        """Apply consistent CSS styling"""
        css_provider = Gtk.CssProvider()
        
        css = """
            window, dialog {
                background-color: @theme_bg_color;
                color: @theme_fg_color;
                font-family: 'Noto Sans', Sans;
                font-size: 12pt;
            }
            
            entry {
                min-height: 24px;
                padding: 6px 12px;
                border-radius: 4px;
            }
            
            button {
                min-height: 24px;
                padding: 6px 12px;
                border-radius: 4px;
            }
            
            frame.phase-frame {
                background-color: shade(@theme_bg_color, 0.95);
                border-radius: 8px;
                border: 1px solid @borders;
                padding: 15px;
                margin: 10px;
            }
            
            button.destructive {
                background: @error_bg_color;
                color: @theme_fg_color;
            }
            progressbar, progress {
                min-height: 15px;  /* Makes the progress bar thicker */
                font-size: 12px;   /* Optional: Adjust text size */
            }
    
            progressbar trough {
                min-height: 15px;
                background-color: @theme_bg_color;
            }
    
            progressbar progress {
                min-height: 15px;
                background-color: @theme_selected_bg_color;
            }            
        """
        
        css_provider.load_from_data(css.encode())
        
        display = Gdk.Display.get_default()
        Gtk.StyleContext.add_provider_for_display(
            display,
            css_provider,
            Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION
        )
        
        if hasattr(widget, 'add_css_provider'):
            widget.add_css_provider(css_provider)

    def open_date_picker(self, button=None, callback=None):  # Add button=None
        """Open date selection dialog"""
        dialog = Gtk.Dialog(transient_for=self, modal=True)
        dialog.set_title(_("Select Date"))
        
        # Header bar with buttons
        header = Gtk.HeaderBar()
        dialog.set_titlebar(header)
        
        cancel_btn = Gtk.Button(label=_("Cancel"))
        cancel_btn.connect("clicked", lambda *_: dialog.close())
        header.pack_start(cancel_btn)
        
        confirm_btn = Gtk.Button(label=_("Confirm"))
        confirm_btn.add_css_class("suggested-action")
        def on_confirm(*args):
            self.on_date_selected(confirm_btn,dialog)
            dialog.close()
            if callback: callback()
        confirm_btn.connect("clicked", on_confirm)
        header.pack_end(confirm_btn)
        
        calendar = Gtk.Calendar()
        dialog.set_child(calendar)
        dialog.present()

    def on_date_selected(self, button, dialog):
        """Handle date selection from calendar"""
        calendar = dialog.get_child()
        date = calendar.get_date()
        self.selected_date = f"{date.get_year():04d}-{date.get_month():02d}-{date.get_day_of_month():02d}"
        self.date_label.set_text(_("Selected backup start date: {0}").format(self.selected_date))
        dialog.close()

    def run_backup(self, button):
        """Initiate backup process"""        
        if not hasattr(self, "selected_date")  or self.selected_date is None:
            self.append_output("⚠️" + _("Select Modified Files Start Date")+"\n")
            self.open_date_picker(  # Auto-open picker            
               callback=lambda: GLib.idle_add(self.run_backup, button)  # ← Now a proper callback                  
            )
            return
        
        self.progress_bar.set_fraction(0.0)
        self.progress_bar.set_text(_("Preparing..."))
        self.output_buffer.set_text(_("Starting backup...")+"\n")
        self.total_files = 0
        self.processed_files = 0
        
        for phase in self.phases.values():
            phase["completed"] = 0.0
            phase["file_count"] = 0
            phase["processed_in_phase"] = 0
            phase["weight"] = 0.0
        
        if not self.progress_updater_running:
            GLib.timeout_add(100, self.update_progress_from_queue)
            self.progress_updater_running = True
        
        Thread(target=self.execute_backup, daemon=True).start()




    def _show_date_picker(self, on_confirm=None):
        """Internal date picker without button dependency"""
        dialog = Gtk.Dialog(transient_for=self, modal=True)
        # ... rest of the picker code ...
        confirm_btn.connect("clicked", lambda *_: (
            self._handle_date_selection(calendar.get_date()),
            dialog.close(),
            on_confirm and on_confirm()
        ))

    def execute_backup(self):
        """Main backup execution method"""
        #_ = gettext.gettext
        # Initialize translations for this thread
        gettext.textdomain('gtkbackuprunner')       
        self._init_translations(self.current_language)
        # Debug output
        #print(f"Thread domain: {gettext._current_domain}")
        #print(f"Test translation: {_('Starting file scan...')}")
        #self.append_output(f"Thread domain: {gettext._current_domain}\n")
        
        try:
            self.append_output("🔎"+_("Starting file scan...") + "\n")
            self.count_all_files()
            
            if self.total_files == 0:
                self.progress_queue.put(('error',"❌"+ _( "No files found to backup")))
                return
            
            self.append_output(_("Found {0} files to backup").format(self.total_files)+ "\n")
            
            for phase_id, phase in self.phases.items():
                self.current_phase = phase_id
                self.phases[phase_id]["processed_in_phase"] = 0
                self.append_output(_("\n🚩️Preparing {0} backup...").format(phase['name']) + "\n")
                self.execute_phase(phase_id)
            
            self.progress_queue.put(('complete', _("🎉 Backup completed!")))
            self.progress_queue.put(('progress', 1.0))
        except Exception as e:
            self.progress_queue.put(('error',"❌" + _("Error occurred: {0}").format(str(e))))
            import traceback
            self.append_output(traceback.format_exc())

    def count_files(self, phase_id, phase):
        """Count files matching criteria in directory"""        
        try:
            phase_cfg = self.phases[phase_id]
            expanded_dir = os.path.expanduser(phase_cfg["source"])
            
            if not os.path.exists(expanded_dir):
                self.append_output("⚠️" + _("Source directory {0} doesn't exist, using default documents directory\n").format(expanded_dir))
                return 0
                
            count = 0
            selected_date = datetime.strptime(self.selected_date, "%Y-%m-%d")
            patterns = [p.strip() for p in phase_cfg["file_patterns"].split(",")]
            exclude_patterns = [p.strip() for p in phase_cfg["exclude_patterns"].split(",")]            

            self.append_output("\n📡" + _("Scanning {0} files...").format(phase_cfg['name']) + "\n")
            self.append_output(_("Directory: {0}").format(expanded_dir) + "\n")
            self.append_output(_("File patterns: {0}").format(patterns) + "\n")
            self.append_output(_("Exclude patterns: {0}").format(exclude_patterns) + "\n")

            for root, _dirs, files in os.walk(expanded_dir):
                for file in files:
                    file_path = Path(root) / file
                    try:
                        file_mtime = datetime.fromtimestamp(file_path.stat().st_mtime)
                        if file_mtime >= selected_date:
                            if self.file_matches_criteria(file_path, phase_cfg, False):
                                count += 1
                    except Exception as e:
                        self.append_output("")
            
            self.append_output(_("Found {0} {1} files" ).format(count, phase_cfg['name'])+ "\n")
            return count
                
        except Exception as e:
            self.append_output( "⚠️" + _("Error counting {0} files: {1}" ).format(phase_cfg['name'], str(e))+ "\n")
            return 0

    def file_matches_criteria(self, file_path, phase, show_output=True):
        """File pattern matching with universal exclude patterns"""
        filename = file_path.name.lower()
        
        user_include = [p.strip().lower() for p in phase["file_patterns"].split(",") if p.strip()]
        user_exclude = [p.strip().lower() for p in phase["exclude_patterns"].split(",") if p.strip()]
        
        universal_exclude = [
            '*.tmp', '*.temp', '*.bak', '*.backup',
            '*.swp', '~*', '*.~*', '*.log', '*.cache',
            '*.DS_Store', 'Thumbs.db', '*Zone.Identifier*',
            '*.part', '*.download', '*.crdownload',
            '*.pid', '*.lock', '*.lck', '*.aria2',
            '*.synctex.gz', '*.aux', '*.toc'
        ]
        
        if user_include and "*" not in user_include:
            for pattern in user_include:
                if fnmatch.fnmatch(filename, pattern):
                    return True
            return False

        all_excludes = user_exclude + universal_exclude
        for pattern in all_excludes:
            if fnmatch.fnmatch(filename, pattern):
                if pattern in universal_exclude and show_output and pattern not in user_exclude:
                    self.append_output(_("× Excluded system file: {0}").format(filename) + "\n")
                return False

        return True

    def execute_phase(self, phase_id):
        """Execute backup phase with progress tracking"""
        _ = gettext.gettext
        # Reinitialize translations
        self._init_translations(self.current_language)
        phase = self.phases[phase_id]
        self.progress_queue.put(('phase_start', (phase_id, phase["name"])))
        self.append_output("\n🚀️ "+_("Starting {0} backup...").format(phase['name']) + "\n")

        try:
            source_dir = os.path.expanduser(phase["source"]) if phase["source"] else self.get_documents_dir()
            target_dir = os.path.expanduser(phase["target"]) if phase["target"] else self.get_download_dir()
            phase["source"] = source_dir
            phase["target"] = target_dir
            os.makedirs(target_dir, exist_ok=True)

            selected_date = datetime.strptime(self.selected_date, "%Y-%m-%d")
            selected_date_short_string = selected_date.strftime('%Y%m%d')
            zip_filename = f"{phase['name']}_{time.strftime('%Y%m%d')}_" + _("modified_since_") + selected_date_short_string+".zip"
            zip_path = os.path.join(target_dir, zip_filename)

            processed_files = 0
            total_files = max(phase["file_count"], 1)

            with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
                for root, _dirs, files in os.walk(source_dir):
                    for file in files:
                        file_path = Path(root) / file
                        try:
                            file_mtime = datetime.fromtimestamp(file_path.stat().st_mtime)
                            if file_mtime >= selected_date and self.file_matches_criteria(file_path, phase):
                                rel_path = os.path.relpath(file_path, os.path.dirname(source_dir))
                                zipf.write(file_path, rel_path)
                                processed_files += 1
                                phase["processed_in_phase"] = processed_files

                                phase_progress = processed_files / total_files
                                total_weight = sum(p["weight"] for p in self.phases.values())
                                current_weight = phase["weight"] / total_weight
                                overall_progress = sum(
                                    p["weight"] * (p["processed_in_phase"] / max(p["file_count"], 1))
                                    for p in self.phases.values()
                                ) / total_weight

                                self.append_output(
                                    _("✓ {0}/{1} {2}\n").format(processed_files, total_files, rel_path) +
                                    _("{0} phase progress: {1}%").format(phase['name'], math.floor(phase_progress*100)) +                               
                                    _("Total progress: {0}%" ).format(math.floor(overall_progress*100))+ "\n"
                                )

                                self.progress_queue.put(('progress', min(overall_progress, 0.99)))

                        except Exception as e:
                            self.append_output("⚠️" + _("Skipped: {0} ({1})").format(file_path, str(e) + "\n"))

            phase["processed_in_phase"] = processed_files
            self.append_output(_("✅ {0} completed {1} files, created zip at {2}" ).format(
                phase['name'], processed_files, phase['target'])+ "\n")
        except Exception as e:
            self.append_output(_("❌ {0} failed: {1}").format(phase['name'], str(e)) + "\n")
            self.progress_queue.put(('error', _("{0} backup failed").format(phase['name'])))

    def count_all_files(self):
        """Count files and calculate proper weights"""
        total_files = 0
        
        for phase_id, phase in self.phases.items():
            count = self.count_files(phase_id, phase)
            self.phases[phase_id]["file_count"] = count
            total_files += count
        
        for phase_id, phase in self.phases.items():
            phase["weight"] = phase["file_count"] / max(total_files, 1)
        
        self.total_files = total_files
        self.append_output(_("Total {0} files to backup").format(self.total_files) + "\n")

    def get_download_dir(self):
        """Get system download directory"""
        try:
            result = subprocess.run(['xdg-user-dir', 'DOWNLOAD'], 
                                  capture_output=True, 
                                  text=True)
            dest_dir = result.stdout.strip()
            if not dest_dir or not os.path.exists(dest_dir):
                dest_dir = os.path.expanduser("~/Downloads")
            
            os.makedirs(dest_dir, exist_ok=True)
            return dest_dir
        except:
            return os.path.expanduser("~/Downloads")

    def get_documents_dir(self):
        """Get system documents directory"""
        try:
            result = subprocess.run(['xdg-user-dir', 'DOCUMENTS'], 
                                  capture_output=True, 
                                  text=True)
            dest_dir = result.stdout.strip()
            if not dest_dir or not os.path.exists(dest_dir):
                dest_dir = os.path.expanduser("~/Documents")
            
            os.makedirs(dest_dir, exist_ok=True)
            return dest_dir
        except:
            return os.path.expanduser("~/Documents")

    def update_progress_from_queue(self):
        """Process messages from backup thread"""
        try:
            while True:
                item = self.progress_queue.get_nowait()
                
                if item[0] == 'progress':
                    GLib.idle_add(self.progress_bar.set_fraction, item[1])
                    current_phase = self.phases[self.current_phase]
                    phase_progress = sum(
                        p["weight"] * p["completed"] 
                        for p in self.phases.values()
                    )
                    GLib.idle_add(
                        self.progress_bar.set_text, 
                        _("{0}% - {1} ({2}/{3})").format(
                            int(phase_progress*100),
                            current_phase['name'],
                            current_phase['processed_in_phase'],
                            current_phase['file_count'])
                    )
                elif item[0] == 'output':
                    self.append_output(item[1])
                elif item[0] == 'phase_start':
                    GLib.idle_add(
                        self.progress_bar.set_text, 
                        _("Processing {0}...").format(item[1][1])
                    )
                elif item[0] == 'complete':
                    GLib.idle_add(self.progress_bar.set_fraction, 1.0)
                    GLib.idle_add(self.progress_bar.set_text, _("Completed"))
                    self.append_output(f"\n{item[1]}\n")
                elif item[0] == 'error':
                    self.append_output(f"\n{item[1]}\n")
                    GLib.idle_add(self.progress_bar.set_text, "❌ " + _("Failed"))
                    GLib.timeout_add(5000, self.reset_progress_bar)
                    
        except queue.Empty:
            pass
        
        return True

    def append_output(self, text):
        """Add text to output console with auto-scroll"""
        def _append():
            end_iter = self.output_buffer.get_end_iter()
            self.output_buffer.insert(end_iter, text)
            
            mark = self.output_buffer.create_mark(None, end_iter, True)
            self.output_view.scroll_to_mark(mark, 0.0, True, 0.0, 1.0)
        
        GLib.idle_add(_append)
    
    def reset_progress_bar(self):
        """Reset progress bar after completion"""
        self.progress_bar.set_fraction(0.0)
        self.progress_bar.set_text("")
        self.progress_updater_running = False
        return False

    def on_language_changed(self, combo, *args):
        """Handle language change with environment variable setting"""
        selected = combo.get_selected()
        if selected != Gtk.INVALID_LIST_POSITION and selected < len(self.lang_map):
            new_lang = self.lang_map[selected]
            
            if new_lang != self.current_language:
                try:
                    # Prepare environment for new process
                    env = os.environ.copy()
                    env['LANGUAGE'] = new_lang
                    env['LC_ALL'] = f"{new_lang}.UTF-8"
                    env['LANG'] = f"{new_lang}.UTF-8"
                    
                    # Prepare command
                    cmd = [sys.executable, __file__, "--lang", new_lang]
                    if "--lang" in sys.argv:
                        lang_index = sys.argv.index("--lang")
                        cmd += [arg for arg in sys.argv[1:] if arg != "--lang" and arg != sys.argv[lang_index+1]]
                    else:
                        cmd += sys.argv[1:]
                    
                    # Start new instance with modified environment
                    subprocess.Popen(cmd, env=env)
                    self.get_application().quit()
                    
                except Exception as e:
                    print(f"Language change error: {e}")
                    self._show_error_dialog(_("Language Change Failed"),
                                          _("Could not switch to selected language."))
                    self._reset_combo_selection(combo)   
    
    def _show_error_dialog(self, title, message):
        """Show an error dialog"""
        dialog = Gtk.MessageDialog(
            transient_for=self,
            modal=True,
            message_type=Gtk.MessageType.ERROR,
            buttons=Gtk.ButtonsType.OK,
            text=title,
            secondary_text=message
        )
        dialog.connect("response", lambda d, r: d.close())
        dialog.present()

    def _reset_combo_selection(self, combo):
        """Reset language combo to current language"""
        try:
            current_idx = self.lang_map.index(self.current_language)
            combo.set_selected(current_idx)
        except ValueError:
            combo.set_selected(0)

    
class BackupApplication(Gtk.Application):
    def __init__(self):
        super().__init__(application_id="com.example.gtkbackuprunner")
       
    def do_activate(self):
        # Check for language argument
        lang = None
        if "--lang" in sys.argv:
            lang_index = sys.argv.index("--lang") + 1
            if lang_index < len(sys.argv):
                lang = sys.argv[lang_index]
        
        win = BackupApp(self, lang)
        win.present()


if __name__ == "__main__":
    app = BackupApplication()
    app.run(None)
