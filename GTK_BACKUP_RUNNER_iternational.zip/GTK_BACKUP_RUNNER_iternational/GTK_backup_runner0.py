import gi
import subprocess
import os
import time
from threading import Thread
import queue
from datetime import datetime
from pathlib import Path
import zipfile
import shutil

gi.require_version("Gtk", "4.0")
from gi.repository import Gtk, GLib

class BackupApp(Gtk.ApplicationWindow):
    def __init__(self, app):
        super().__init__(application=app, title="備份出納系統")
        self.set_default_size(500, 400)
        
        # Main vertical box
        vbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        vbox.set_margin_top(20)
        vbox.set_margin_bottom(20)
        vbox.set_margin_start(20)
        vbox.set_margin_end(20)
        
        # Title label
        title_label = Gtk.Label(label="備份出納系統檔案，會產生資料庫及程式的備份壓縮檔於「下載」資料夾")
        vbox.append(title_label)
        
        # Date picker button
        self.date_button = Gtk.Button(label="選擇日期")
        self.date_button.connect("clicked", self.open_date_picker)
        vbox.append(self.date_button)
        
        # Selected date display
        self.date_label = Gtk.Label(label="選擇的日期: 無")
        vbox.append(self.date_label)
        
        # Backup button
        self.button = Gtk.Button(label="執行備份")
        self.button.connect("clicked", self.run_backup)
        vbox.append(self.button)
        
        # Progress bar
        self.progress_bar = Gtk.ProgressBar()
        vbox.append(self.progress_bar)
        
        # Output console
        self.output_view = Gtk.TextView()
        self.output_view.set_editable(False)
        self.output_view.set_wrap_mode(Gtk.WrapMode.WORD)
        self.output_buffer = self.output_view.get_buffer()
        
        scroll = Gtk.ScrolledWindow()
        scroll.set_child(self.output_view)
        scroll.set_min_content_height(150)
        vbox.append(scroll)
        
        self.set_child(vbox)
        
        # Progress tracking
        self.progress_queue = queue.Queue()
        self.progress_updater_running = False
        self.total_files = 0
        self.processed_files = 0
        self.current_phase = ""
        
        # Phase configuration - weights will be calculated dynamically
        self.phases = {
            "database": {
                "name": "資料庫備份",
                "completed": 0.0,
                "file_count": 0,
                "processed_in_phase": 0,
                "weight": 0.0  # Will be calculated based on actual file counts
            },
            "source": {
                "name": "程式檔案備份",
                "completed": 0.0,
                "file_count": 0,
                "processed_in_phase": 0,
                "weight": 0.0
            },
            "data": {
                "name": "數據檔案備份",
                "completed": 0.0,
                "file_count": 0,
                "processed_in_phase": 0,
                "weight": 0.0
            }
        }

    def open_date_picker(self, button):
        """Open calendar dialog for date selection"""
        dialog = Gtk.Dialog(transient_for=self, modal=True)
        dialog.set_title("選擇日期")
        
        # Create header bar
        header = Gtk.HeaderBar()
        dialog.set_titlebar(header)
        
        # Add cancel button
        cancel_btn = Gtk.Button(label="取消")
        cancel_btn.connect("clicked", lambda *_: dialog.close())
        header.pack_start(cancel_btn)
        
        # Add confirm button
        confirm_btn = Gtk.Button(label="確定")
        confirm_btn.add_css_class("suggested-action")
        confirm_btn.connect("clicked", self.on_date_selected, dialog)
        header.pack_end(confirm_btn)
        
        # Add calendar
        calendar = Gtk.Calendar()
        dialog.set_child(calendar)
        
        dialog.present()

    def on_date_selected(self, button, dialog):
        """Handle date selection from calendar"""
        calendar = dialog.get_child()
        date = calendar.get_date()
        self.selected_date = f"{date.get_year():04d}-{date.get_month():02d}-{date.get_day_of_month():02d}"
        self.date_label.set_text(f"選擇的日期: {self.selected_date}")
        dialog.close()

    def run_backup(self, button):
        """Initiate backup process"""
        if not hasattr(self, "selected_date"):
            self.append_output("請選擇日期。\n")
            return
        
        # Reset progress tracking
        self.progress_bar.set_fraction(0.0)
        self.progress_bar.set_text("準備中...")
        self.output_buffer.set_text("開始備份...\n")
        self.total_files = 0
        self.processed_files = 0
        
        for phase in self.phases.values():
            phase["completed"] = 0.0
            phase["file_count"] = 0
            phase["processed_in_phase"] = 0
            phase["weight"] = 0.0
        
        if not self.progress_updater_running:
            GLib.timeout_add(100, self.update_progress_from_queue)
            self.progress_updater_running = True
        
        # Start backup in separate thread
        Thread(target=self.execute_backup, daemon=True).start()

    def execute_backup(self):
        """Main backup execution method"""
        try:
            # Count files first to determine weights
            self.count_all_files()
            
            if self.total_files == 0:
                self.progress_queue.put(('error', "❌ 沒有找到需要備份的檔案"))
                return
            
            # Calculate dynamic weights based on actual file counts
            for phase in self.phases.values():
                if self.total_files > 0:
                    phase["weight"] = phase["file_count"] / self.total_files
                else:
                    phase["weight"] = 0
            
            self.append_output("\n各階段權重分配:\n")
            for phase_name, phase in self.phases.items():
                self.append_output(f"{phase['name']}: {phase['weight']*100:.1f}% ({phase['file_count']} 個檔案)\n")
            
            # Execute each backup phase
            for phase_name in ["database", "source", "data"]:
                self.current_phase = phase_name
                self.phases[phase_name]["processed_in_phase"] = 0
                self.execute_phase(phase_name)
            
            # Final completion
            self.progress_queue.put(('progress', 1.0))
            self.progress_queue.put(('complete', "🎉 備份完成！"))
        except Exception as e:
            self.progress_queue.put(('error', f"❌ 發生錯誤: {str(e)}"))

    def count_all_files(self):
        """Count files for all phases and calculate total"""
        total = 0
        
        for phase_name in self.phases:
            if phase_name == "data":
                # Special handling for data directory with school year
                current_year = datetime.now().year
                current_month = datetime.now().month
                year_diff = (current_year - 1911) if current_month >= 8 else (current_year - 1912)
                directory = f"/DATA/公務/{year_diff}出納"
            else:
                directory = "~/public_html"
            
            count = self.count_files(directory, phase_name)
            self.phases[phase_name]["file_count"] = count
            self.append_output(f"找到 {count} 個{self.phases[phase_name]['name']}需要備份\n")
            total += count
        
        self.total_files = total
        self.append_output(f"總共 {self.total_files} 個檔案需要備份\n")

    def count_files(self, directory, phase_name):
        """Count files matching criteria in directory"""
        try:
            expanded_dir = os.path.expanduser(directory)
            
            if not os.path.exists(expanded_dir):
                self.append_output(f"⚠️ 目錄不存在: {expanded_dir}\n")
                return 0
                
            count = 0
            selected_date = datetime.strptime(self.selected_date, "%Y-%m-%d")
            
            for root, _, files in os.walk(expanded_dir):
                for file in files:
                    file_path = Path(root) / file
                    
                    # Check modification time
                    try:
                        file_mtime = datetime.fromtimestamp(file_path.stat().st_mtime)
                        if file_mtime >= selected_date:
                            # Check file type criteria
                            if self.file_matches_criteria(file_path, phase_name):
                                count += 1
                    except:
                        continue
            
            return count
                
        except Exception as e:
            self.append_output(f"⚠️ 計算 {directory} 檔案數量時出錯: {str(e)}\n")
            return 0

    def execute_phase(self, phase_name):
        """Execute a backup phase using Python's zipfile"""
        phase = self.phases[phase_name]
        self.append_output(f"\n▶️ 開始 {phase['name']}...\n")
        self.progress_queue.put(('phase_start', phase['name']))
        
        # Special handling for data directory
        if phase_name == "data":
            current_year = datetime.now().year
            current_month = datetime.now().month
            year_diff = (current_year - 1911) if current_month >= 8 else (current_year - 1912)
            directory = f"/DATA/公務/{year_diff}出納"
            parent_folder_name = f"{year_diff}出納"  # The folder name we want in the zip
        else:
            directory = "~/public_html"
            parent_folder_name = "public_html"  # The folder name we want in the zip
        
        expanded_dir = os.path.expanduser(directory)
        dest_dir = self.get_download_dir()
        zip_path = os.path.join(dest_dir, f"modified_{phase_name}_files_{time.strftime('%Y%m%d')}.zip")
        selected_date = datetime.strptime(self.selected_date, "%Y-%m-%d")
        
        try:
            with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
                files_added = 0
                total_in_phase = phase["file_count"]
                
                for root, _, files in os.walk(expanded_dir):
                    for file in files:
                        file_path = Path(root) / file
                        
                        try:
                            # Check modification time and criteria
                            file_mtime = datetime.fromtimestamp(file_path.stat().st_mtime)
                            if (file_mtime >= selected_date and 
                                self.file_matches_criteria(file_path, phase_name)):
                                
                                # Calculate relative path from the parent directory
                                rel_path = os.path.relpath(file_path, os.path.dirname(expanded_dir))
                                
                                # Add to zip with the parent folder structure
                                zipf.write(file_path, rel_path)
                                files_added += 1
                                
                                # Update progress
                                self.processed_files += 1
                                phase["processed_in_phase"] = files_added
                                phase["completed"] = files_added / max(total_in_phase, 1)
                                
                                # Calculate overall progress
                                total_progress = sum(
                                    p["weight"] * p["completed"] 
                                    for p in self.phases.values()
                                )
                                self.progress_queue.put(('progress', min(total_progress, 0.99)))
                                self.append_output(f"已添加: {rel_path}\n")
                        except Exception as e:
                            self.append_output(f"⚠️ 跳過檔案 {file_path}: {str(e)}\n")
                            continue
            
            phase["completed"] = 1.0
            total_progress = sum(p["weight"] * p["completed"] for p in self.phases.values())
            self.progress_queue.put(('progress', min(total_progress, 0.99)))
            self.append_output(f"✅ {phase['name']}完成 (處理 {files_added}/{phase['file_count']} 個檔案)\n")
            
        except Exception as e:
            self.append_output(f"❌ 創建壓縮檔時出錯: {str(e)}\n")
            self.progress_queue.put(('error', f"{phase['name']} 失敗"))

    def file_matches_criteria(self, file_path, phase_name):
        """Check if file matches the criteria for the given phase"""
        filename = file_path.name.lower()
        
        if phase_name == "database":
            return filename.endswith(('.db', '.sqlite', '.sqlite3'))
        elif phase_name == "source":
            return not filename.endswith(('.sqlite', '.db'))
        elif phase_name == "data":
            excluded_patterns = [
                '*zone.identifier*',
                '*.~lock.*',
                '*.tmp',
                '*.bak',
                '*.swp',
                '*.log',
                '*~',
                '.*'
            ]
            return not any(filename.endswith(p.strip('*')) or filename == p.strip('*') 
                         for p in excluded_patterns)
        return False

    def get_download_dir(self):
        """Get system download directory"""
        try:
            result = subprocess.run(['xdg-user-dir', 'DOWNLOAD'], 
                                  capture_output=True, 
                                  text=True)
            dest_dir = result.stdout.strip()
            if not dest_dir or not os.path.exists(dest_dir):
                dest_dir = os.path.expanduser("~/Downloads")
            
            os.makedirs(dest_dir, exist_ok=True)
            return dest_dir
        except:
            return os.path.expanduser("~/Downloads")

    def update_progress_from_queue(self):
        """Process messages from backup thread"""
        try:
            while True:
                item = self.progress_queue.get_nowait()
                
                if item[0] == 'progress':
                    GLib.idle_add(self.progress_bar.set_fraction, item[1])
                    current_phase = self.phases[self.current_phase]
                    phase_progress = sum(
                        p["weight"] * p["completed"] 
                        for p in self.phases.values()
                    )
                    GLib.idle_add(
                        self.progress_bar.set_text, 
                        f"{int(phase_progress*100)}% - {current_phase['name']} "
                        f"({current_phase['processed_in_phase']}/{current_phase['file_count']})"
                    )
                elif item[0] == 'output':
                    self.append_output(item[1])
                elif item[0] == 'phase_start':
                    GLib.idle_add(
                        self.progress_bar.set_text, 
                        f"正在 {item[1]}..."
                    )
                    self.append_output(f"\n▶️ 開始 {item[1]}...\n")
                elif item[0] == 'complete':
                    GLib.idle_add(self.progress_bar.set_fraction, 1.0)
                    GLib.idle_add(self.progress_bar.set_text, "完成")
                    self.append_output(f"\n{item[1]}\n")
                    GLib.timeout_add(5000, self.reset_progress_bar)
                elif item[0] == 'error':
                    self.append_output(f"\n{item[1]}\n")
                    GLib.idle_add(self.progress_bar.set_text, "❌ 失敗")
                    GLib.timeout_add(5000, self.reset_progress_bar)
                    
        except queue.Empty:
            pass
        
        return True  # Continue calling this method

    def append_output(self, text):
        """Add text to output console with auto-scroll"""
        def _append():
            end_iter = self.output_buffer.get_end_iter()
            self.output_buffer.insert(end_iter, text)
            
            # Auto-scroll to bottom
            mark = self.output_buffer.create_mark(None, end_iter, True)
            self.output_view.scroll_to_mark(mark, 0.0, True, 0.0, 1.0)
        
        GLib.idle_add(_append)
    
    def reset_progress_bar(self):
        """Reset progress bar after completion"""
        self.progress_bar.set_fraction(0.0)
        self.progress_bar.set_text("")
        self.progress_updater_running = False
        return False  # Stop timeout

class BackupApplication(Gtk.Application):
    def __init__(self):
        super().__init__(application_id="com.example.backupapp")

    def do_activate(self):
        win = BackupApp(self)
        win.present()

app = BackupApplication()
app.run(None)
