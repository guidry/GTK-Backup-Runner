#!/bin/bash

# Check if the user has passed a date as an argument; if not, use today's date
if [ -z "$1" ]; then
  DATE=$(date +'%Y-%m-%d')  # Get today's date
else
  DATE="$1"  # Use the supplied date argument
fi

# Define source and destination directories
SOURCE_DIR=~/public_html

# Get the system's default Downloads folder dynamically
DEST_DIR=$(xdg-user-dir DOWNLOAD)

# Check if xdg-user-dir failed to return a valid directory, fall back to ~/Downloads
if [ -z "$DEST_DIR" ]; then
  DEST_DIR="$HOME/Downloads"
fi
# Check if the destination directory exists, and create it if not
if [ ! -d "$DEST_DIR" ]; then
  echo "Destination directory does not exist. Creating $DEST_DIR..."
  mkdir -p "$DEST_DIR"
fi

# Define the name of the zip file
ZIP_FILE="$DEST_DIR/modified_source_files_$(date +'%Y%m%d').zip"

# Create the zip file, including only files modified **on or after** the specified date, and excluding .sqlite and .db files
find "$SOURCE_DIR" -type f -newermt "$DATE" ! -name "*.sqlite" ! -name "*.db" | zip "$ZIP_FILE" -@
echo "Files modified on and after $DATE have been backed up (excluding .sqlite and .db files)."
echo "Zip file created: $ZIP_FILE"

