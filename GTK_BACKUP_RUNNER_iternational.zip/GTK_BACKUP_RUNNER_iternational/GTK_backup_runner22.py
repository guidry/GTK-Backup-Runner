import gi
import subprocess
import os
import fnmatch
import time
from threading import Thread
import queue
from datetime import datetime
from pathlib import Path
gi.require_version("Gtk", "4.0")
gi.require_version("Gdk", "4.0")
from gi.repository import Gtk, Gio, Gdk
import zipfile
import shutil
import configparser
import json

gi.require_version("Gtk", "4.0")
from gi.repository import Gtk, GLib, Gio

class BackupApp(Gtk.ApplicationWindow):
    def __init__(self, app):
        super().__init__(application=app, title="備份執行器")        
        self.apply_consistent_styling(self)
        self.set_default_size(600, 500)      
 
        
        # Configuration
        self.config_dir = os.path.join(os.path.expanduser("~"), ".config")
        self.config_path = os.path.join(self.config_dir, "xu-backup-runner.conf")
        self.phases = {}
        self.load_config()
        
        # Main vertical box
        vbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        vbox.set_margin_top(20)
        vbox.set_margin_bottom(20)
        vbox.set_margin_start(20)
        vbox.set_margin_end(20)
        
        # Title label
        title_label = Gtk.Label(label="備份執行器 - 根據設定檔備份多個目錄")
        vbox.append(title_label)
        
        # Setup button
        setup_button = Gtk.Button(label="設定備份任務")
        setup_button.connect("clicked", self.show_setup_dialog)
        vbox.append(setup_button)
        
        # Date picker button
        self.date_button = Gtk.Button(label="選擇日期")
        self.date_button.connect("clicked", self.open_date_picker)
        vbox.append(self.date_button)
        
        # Selected date display
        self.date_label = Gtk.Label(label="選擇的日期: 無")
        vbox.append(self.date_label)
        
        # Backup button
        self.backup_button = Gtk.Button(label="執行備份")
        self.backup_button.connect("clicked", self.run_backup)
        vbox.append(self.backup_button)
        
        # Progress bar
        self.progress_bar = Gtk.ProgressBar()
        vbox.append(self.progress_bar)
        
        # Output console
        self.output_view = Gtk.TextView()
        self.output_view.set_editable(False)
        self.output_view.set_wrap_mode(Gtk.WrapMode.WORD)
        self.output_buffer = self.output_view.get_buffer()
        
        scroll = Gtk.ScrolledWindow()
        scroll.set_child(self.output_view)
        scroll.set_min_content_height(200)
        vbox.append(scroll)
        
        self.set_child(vbox)
        
        # Progress tracking
        self.progress_queue = queue.Queue()
        self.progress_updater_running = False
        self.total_files = 0
        self.processed_files = 0
        self.current_phase = ""

    def load_config(self):
        """Load configuration from file"""
        if not os.path.exists(self.config_path):
            self.phases = {
                "example": {
                    "name": "範例備份",
                    "source": "~/Documents",
                    "target": "~/Backups",
                    "file_patterns": "*",
                    "exclude_patterns": ""
                }
            }
            self.save_config()
            return
        
        config = configparser.ConfigParser()
        config.read(self.config_path)
        
        self.phases = {}
        for section in config.sections():
            self.phases[section] = {
                "name": config.get(section, "name", fallback=section),
                "source": config.get(section, "source"),
                "target": config.get(section, "target", fallback=""),
                "file_patterns": config.get(section, "file_patterns", fallback="*"),
                "exclude_patterns": config.get(section, "exclude_patterns", fallback="")
            }

    def remove_phase(self, frame, phase_id):
        """Remove a backup phase from both UI and configuration"""
        # Remove from configuration
        if phase_id in self.phases:
            del self.phases[phase_id]
        
        # Remove from UI
        self.phases_container.remove(frame)
        
        # Force UI update
        self.phases_container.queue_draw()

    
 
 
 



    def add_new_phase_ui(self, button):
        """Add UI for a new phase"""
        phase_id = f"phase_{len(self.phases) + 1}"
        self.phases[phase_id] = {
            "name": "新備份階段",
            "source": "",
            "target": "",
            "file_patterns": "*",
            "exclude_patterns": ""
        }
        self.add_phase_ui(phase_id, self.phases[phase_id])


    def save_config_from_dialog(self, dialog):
        """Save configuration from dialog inputs"""
        # First collect all data from UI
        for phase_id, phase in list(self.phases.items()):
            if "ui" in phase:
                # Update phase data from UI
                phase["name"] = phase["ui"]["name"].get_text()
                phase["source"] = phase["ui"]["source"].get_text()
                phase["target"] = phase["ui"]["target"].get_text()
                phase["file_patterns"] = phase["ui"]["patterns"].get_text()
                phase["exclude_patterns"] = phase["ui"]["exclude"].get_text()
                
                # Clean up UI references
                del phase["ui"]
                
                # Remove empty phases
                if not phase["name"] and not phase["source"]:
                    del self.phases[phase_id]
        
        # Save to config file
        self.save_config()
        dialog.close()
        self.append_output("設定已儲存\n")

    def save_config(self):
        """Save configuration to file"""
        os.makedirs(self.config_dir, exist_ok=True)
        
        config = configparser.ConfigParser()
        
        # Create sections with clean IDs based on phase names
        for phase_id, phase in self.phases.items():
            # Create a clean section name
            clean_id = phase["name"].strip().replace(" ", "_")
            if not clean_id:
                clean_id = f"phase_{phase_id}"
            
            config[clean_id] = {
                "name": phase["name"],
                "source": phase["source"],
                "target": phase["target"],
                "file_patterns": phase["file_patterns"],
                "exclude_patterns": phase["exclude_patterns"]
            }
        
        with open(self.config_path, 'w', encoding='utf-8') as configfile:
            config.write(configfile)


 

    def select_directory(self, entry_widget):
        """Modern GTK4 directory selection with proper async handling"""
        dialog = Gtk.FileDialog(
            title="選擇目錄",
            modal=True
        )
        
        # Set initial folder if exists
        current_path = entry_widget.get_text()
        if current_path and os.path.exists(current_path):
            dialog.set_initial_folder(Gio.File.new_for_path(current_path))
        
        def on_finish(dialog, result):
            try:
                file = dialog.select_folder_finish(result)
                if file:
                    entry_widget.set_text(file.get_path())
            except GLib.Error as err:
                print(f"Error selecting folder: {err}")
        
        dialog.select_folder(
            parent=self,
            cancellable=None,
            callback=on_finish
        )









    def show_setup_dialog(self, button):
        """Show the backup configuration dialog with proper GTK4 implementation"""
        dialog = Gtk.Dialog(transient_for=self, modal=True)                
        self.apply_consistent_styling(dialog)  # Apply same styling to dialog
        dialog.set_title("設定備份任務")
        dialog.set_default_size(700, 650)
        
        # Apply main window styling to dialog
        self.apply_consistent_styling(dialog)
        
        # Create header bar
        header = Gtk.HeaderBar()
        dialog.set_titlebar(header)
        
        # Add buttons to header
        cancel_btn = Gtk.Button(label="取消")
        cancel_btn.connect("clicked", lambda *_: dialog.close())
        header.pack_start(cancel_btn)
        
        save_btn = Gtk.Button(label="儲存設定")
        save_btn.add_css_class("suggested-action")
        save_btn.connect("clicked", lambda b: self.save_config_from_dialog(dialog))
        header.pack_end(save_btn)
        
        new_btn = Gtk.Button(label="新增階段")
        new_btn.connect("clicked", self.add_new_phase_ui)
        header.pack_end(new_btn)
        
        # Main container
        main_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        main_box.set_margin_top(10)
        main_box.set_margin_bottom(10)
        main_box.set_margin_start(10)
        main_box.set_margin_end(10)
        
        # Create scrolled window with modern CSS
        scrolled = Gtk.ScrolledWindow()
        scrolled.set_min_content_height(550)
        scrolled.set_policy(
            Gtk.PolicyType.NEVER,
            Gtk.PolicyType.AUTOMATIC
        )
        
        # Apply CSS styling
        css_provider = Gtk.CssProvider()
        css_provider.load_from_data(b"""
            scrolledwindow {
                border: 1px solid #ddd;
                border-radius: 5px;
                background: #000;
            }
            .phase-frame {
                min-height: 300px;
                border-radius: 8px;
                border: 1px solid #aaa;
                background: #444;
                padding: 15px;
                margin: 10px;
            }
            .destructive-btn {
                background: #a00;
                color: #eef;
                margin-top: 15px;
            }
        """)
        
        display = Gdk.Display.get_default()
        Gtk.StyleContext.add_provider_for_display(
            display,
            css_provider,
            Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION
        )
        
        # Phases container
        self.phases_container = Gtk.Box(
            orientation=Gtk.Orientation.VERTICAL,
            spacing=15,
            hexpand=True,
            vexpand=True
        )
        self.phases_container.set_margin_top(10)
        self.phases_container.set_margin_bottom(10)
        self.phases_container.set_margin_start(10)
        self.phases_container.set_margin_end(10)
        
        # Add existing phases
        for phase_id, phase in self.phases.items():
            self.add_phase_ui(phase_id, phase)
        
        scrolled.set_child(self.phases_container)
        main_box.append(scrolled)
        dialog.set_child(main_box)
        dialog.present()

    def add_phase_ui(self, phase_id, phase):
        """Add UI controls for a backup phase with proper GTK4 styling"""
        frame = Gtk.Frame()
        frame.add_css_class("phase-frame")
        
        # Main container
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        box.set_margin_top(10)
        box.set_margin_bottom(10)
        box.set_margin_start(10)
        box.set_margin_end(10)
        
        # Phase name
        name_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        name_label = Gtk.Label(label="階段名稱:", width_request=100, xalign=0)
        name_entry = Gtk.Entry()
        name_entry.set_text(phase["name"])
        name_entry.set_hexpand(True)
        name_entry.set_size_request(-1, 40)
        name_box.append(name_label)
        name_box.append(name_entry)
        box.append(name_box)

        # Source directory
        source_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        source_label = Gtk.Label(label="來源目錄:", width_request=100, xalign=0)
        source_entry = Gtk.Entry()
        source_entry.set_text(phase["source"])
        source_entry.set_hexpand(True)
        source_entry.set_size_request(-1, 40)
        source_button = Gtk.Button(label="選擇...")
        source_button.set_size_request(90, 40)
        source_button.connect("clicked", lambda b, e=source_entry: self.select_directory(e))
        source_box.append(source_label)
        source_box.append(source_entry)
        source_box.append(source_button)
        box.append(source_box)

        # Target directory
        target_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        target_label = Gtk.Label(label="目標目錄:", width_request=100, xalign=0)
        target_entry = Gtk.Entry()
        target_entry.set_text(phase["target"])
        target_entry.set_hexpand(True)
        target_entry.set_size_request(-1, 40)
        target_button = Gtk.Button(label="選擇...")
        target_button.set_size_request(90, 40)
        target_button.connect("clicked", lambda b, e=target_entry: self.select_directory(e))
        target_box.append(target_label)
        target_box.append(target_entry)
        target_box.append(target_button)
        box.append(target_box)

        # File patterns
        patterns_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        patterns_label = Gtk.Label(label="檔案模式:", width_request=100, xalign=0)
        patterns_entry = Gtk.Entry()
        patterns_entry.set_text(phase["file_patterns"])
        patterns_entry.set_hexpand(True)
        patterns_entry.set_size_request(-1, 40)
        patterns_label_tip = Gtk.Label(label="(如: *.php,*.js,*.css)")
        patterns_box.append(patterns_label)
        patterns_box.append(patterns_entry)
        patterns_box.append(patterns_label_tip)
        box.append(patterns_box)

        # Exclude patterns
        exclude_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        exclude_label = Gtk.Label(label="排除模式:", width_request=100, xalign=0)
        exclude_entry = Gtk.Entry()
        exclude_entry.set_text(phase["exclude_patterns"])
        exclude_entry.set_hexpand(True)
        exclude_entry.set_size_request(-1, 40)
        exclude_label_tip = Gtk.Label(label="(如: *.tmp,*.bak,*.log)")
        exclude_box.append(exclude_label)
        exclude_box.append(exclude_entry)
        exclude_box.append(exclude_label_tip)
        box.append(exclude_box)

        # Remove button
        remove_button = Gtk.Button(label="移除階段")
        remove_button.set_size_request(-1, 40)
        remove_button.add_css_class("destructive-btn")
        remove_button.connect("clicked", lambda b, f=frame, pid=phase_id: self.remove_phase(f, pid))
        box.append(remove_button)

        frame.set_child(box)
        self.phases_container.append(frame)
        
        # Store references to entries
        self.phases[phase_id]["ui"] = {
            "name": name_entry,
            "source": source_entry,
            "target": target_entry,
            "patterns": patterns_entry,
            "exclude": exclude_entry
        }

    def apply_consistent_styling(self, widget):
        """Apply consistent CSS styling with proper GTK4 implementation"""
        css_provider = Gtk.CssProvider()
        
        # GTK4-compatible CSS
        css = """
            window, dialog {
                background-color: @theme_bg_color;
                color: @theme_fg_color;
                font-family: 'Noto Sans', Sans;
                font-size: 12pt;
            }
            
            entry {
                min-height: 24px;
                padding: 6px 12px;
                border-radius: 4px;
            }
            
            button {
                min-height: 24px;
                padding: 6px 12px;
                border-radius: 4px;
            }
            
            frame.phase-frame {
                background-color: shade(@theme_bg_color, 0.95);
                border-radius: 8px;
                border: 1px solid @borders;
                padding: 15px;
                margin: 10px;
            }
            
            button.destructive {
                background: @error_bg_color;
                color: @theme_fg_color;
            }
        """
        
        # Load CSS data
        css_provider.load_from_data(css.encode())
        
        # Apply to default display
        display = Gdk.Display.get_default()
        Gtk.StyleContext.add_provider_for_display(
            display,
            css_provider,
            Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION
        )
        
        # For widgets that are already created
        if hasattr(widget, 'add_css_provider'):
            widget.add_css_provider(css_provider)






    def execute_backup(self):
        """Main backup execution method with detailed logging"""
        try:
            self.append_output("開始檔案掃描...\n")
            self.count_all_files()
            
            if self.total_files == 0:
                self.progress_queue.put(('error', "❌ 沒有找到需要備份的檔案"))
                return
            
            self.append_output(f"找到 {self.total_files} 個檔案需要備份\n")
            
            for phase_id, phase in self.phases.items():
                self.current_phase = phase_id
                self.phases[phase_id]["processed_in_phase"] = 0
                self.append_output(f"\n▶️ 開始 {phase['name']}備份...\n")
                self.execute_phase(phase_id)
            
            self.progress_queue.put(('complete', "🎉 備份完成！"))
        except Exception as e:
            self.progress_queue.put(('error', f"❌ 發生錯誤: {str(e)}"))
            import traceback
            self.append_output(traceback.format_exc())

    def count_files(self, phase_id, phase):
        """Count files matching criteria in directory with proper phase access"""
        try:
            # Get phase configuration
            phase_cfg = self.phases[phase_id]
            expanded_dir = os.path.expanduser(phase_cfg["source"])
            
            if not os.path.exists(expanded_dir):
                self.append_output(f"⚠️ 目錄不存在: {expanded_dir}\n")
                return 0
                
            count = 0
            selected_date = datetime.strptime(self.selected_date, "%Y-%m-%d")
            patterns = [p.strip() for p in phase_cfg["file_patterns"].split(",")]
            exclude_patterns = [p.strip() for p in phase_cfg["exclude_patterns"].split(",")]

            self.append_output(f"\n掃描 {phase_cfg['name']} 檔案...\n")
            self.append_output(f"目錄: {expanded_dir}\n")
            self.append_output(f"檔案模式: {patterns}\n")
            self.append_output(f"排除模式: {exclude_patterns}\n")

            for root, _, files in os.walk(expanded_dir):
                for file in files:
                    file_path = Path(root) / file
                    try:
                        file_mtime = datetime.fromtimestamp(file_path.stat().st_mtime)
                        if file_mtime >= selected_date:
                            if self.file_matches_criteria(file_path, phase_cfg):
                                count += 1
                                self.append_output(f"✓ 符合: {file_path}\n")
                    except Exception as e:
                        self.append_output(f"⚠️ 跳過檔案 {file_path}: {str(e)}\n")
            
            self.append_output(f"找到 {count} 個 {phase_cfg['name']} 檔案\n")
            return count
                
        except Exception as e:
            self.append_output(f"⚠️ 計算 {phase_cfg['name']} 檔案數量時出錯: {str(e)}\n")
            return 0

    def file_matches_criteria(self, file_path, phase):
        """File pattern matching with universal exclude patterns"""
        filename = file_path.name.lower()
        
        # User-defined patterns
        user_include = [p.strip().lower() for p in phase["file_patterns"].split(",") if p.strip()]
        user_exclude = [p.strip().lower() for p in phase["exclude_patterns"].split(",") if p.strip()]
        
        # Universal exclude patterns (always applied)
        universal_exclude = [
            '*.tmp', '*.temp', '*.bak', '*.backup',
            '*.swp', '~*', '*.~*', '*.log', '*.cache',
            '*.DS_Store', 'Thumbs.db', '*Zone.Identifier*',
            '*.part', '*.download', '*.crdownload',
            '*.pid', '*.lock', '*.lck', '*.aria2',
            '*.synctex.gz', '*.aux', '*.toc'
        ]
        
        # 1. Check universal excludes first
        for pattern in universal_exclude:
            if fnmatch.fnmatch(filename, pattern):
                self.append_output(f"× 排除系統檔案: {filename} (匹配 {pattern})\n")
                return False
        
        # 2. Check user excludes
        for pattern in user_exclude:
            if fnmatch.fnmatch(filename, pattern):
                self.append_output(f"× 排除用戶設定檔案: {filename} (匹配 {pattern})\n")
                return False
        
        # 3. Handle includes
        if not user_include or "*" in user_include:
            return True  # No specific patterns means include all
        
        # 4. Check user includes
        for pattern in user_include:
            if fnmatch.fnmatch(filename, pattern):
                return True
        
        return False

    def count_all_files(self):
        """Count files for all phases with proper phase access"""
        total = 0
        
        for phase_id, phase in self.phases.items():
            count = self.count_files(phase_id, phase)
            self.phases[phase_id]["file_count"] = count
            self.append_output(f"找到 {count} 個{phase['name']}需要備份\n")
            total += count
        
        self.total_files = total
        self.append_output(f"總共 {self.total_files} 個檔案需要備份\n")







    # [Rest of your existing methods (open_date_picker, on_date_selected, run_backup, 
    # execute_backup, count_all_files, count_files, execute_phase, file_matches_criteria, 
    # get_download_dir, update_progress_from_queue, append_output, reset_progress_bar) 
    # remain the same but should be updated to use the new configuration system]
    
    # Note: The execute_phase method should be updated to use the source/target paths
    # from the configuration rather than hardcoded paths
    def open_date_picker(self, button):
        """Open calendar dialog for date selection"""
        dialog = Gtk.Dialog(transient_for=self, modal=True)
        dialog.set_title("選擇日期")
        
        # Create header bar
        header = Gtk.HeaderBar()
        dialog.set_titlebar(header)
        
        # Add cancel button
        cancel_btn = Gtk.Button(label="取消")
        cancel_btn.connect("clicked", lambda *_: dialog.close())
        header.pack_start(cancel_btn)
        
        # Add confirm button
        confirm_btn = Gtk.Button(label="確定")
        confirm_btn.add_css_class("suggested-action")
        confirm_btn.connect("clicked", self.on_date_selected, dialog)
        header.pack_end(confirm_btn)
        
        # Add calendar
        calendar = Gtk.Calendar()
        dialog.set_child(calendar)
        
        dialog.present()

    def on_date_selected(self, button, dialog):
        """Handle date selection from calendar"""
        calendar = dialog.get_child()
        date = calendar.get_date()
        self.selected_date = f"{date.get_year():04d}-{date.get_month():02d}-{date.get_day_of_month():02d}"
        self.date_label.set_text(f"選擇的日期: {self.selected_date}")
        dialog.close()

    def run_backup(self, button):
        """Initiate backup process"""
        if not hasattr(self, "selected_date"):
            self.append_output("請選擇日期。\n")
            return
        
        # Reset progress tracking
        self.progress_bar.set_fraction(0.0)
        self.progress_bar.set_text("準備中...")
        self.output_buffer.set_text("開始備份...\n")
        self.total_files = 0
        self.processed_files = 0
        
        for phase in self.phases.values():
            phase["completed"] = 0.0
            phase["file_count"] = 0
            phase["processed_in_phase"] = 0
            phase["weight"] = 0.0
        
        if not self.progress_updater_running:
            GLib.timeout_add(100, self.update_progress_from_queue)
            self.progress_updater_running = True
        
        # Start backup in separate thread
        Thread(target=self.execute_backup, daemon=True).start()

    def execute_backup_old(self):
        """Main backup execution method"""
        try:
            # Count files first to determine weights
            self.count_all_files()
            
            if self.total_files == 0:
                self.progress_queue.put(('error', "❌ 沒有找到需要備份的檔案"))
                return
            
            # Calculate dynamic weights based on actual file counts
            for phase in self.phases.values():
                if self.total_files > 0:
                    phase["weight"] = phase["file_count"] / self.total_files
                else:
                    phase["weight"] = 0
            
            self.append_output("\n各階段權重分配:\n")
            for phase_id, phase in self.phases.items():
                self.append_output(f"{phase['name']}: {phase['weight']*100:.1f}% ({phase['file_count']} 個檔案)\n")
            
            # Execute each backup phase
            for phase_id in self.phases:
                self.current_phase = phase_id
                self.phases[phase_id]["processed_in_phase"] = 0
                self.execute_phase(phase_id)
            
            # Final completion
            self.progress_queue.put(('progress', 1.0))
            self.progress_queue.put(('complete', "🎉 備份完成！"))
        except Exception as e:
            self.progress_queue.put(('error', f"❌ 發生錯誤: {str(e)}"))

    def count_all_files_old(self):
        """Count files for all phases and calculate total"""
        total = 0
        
        for phase_id, phase in self.phases.items():
            count = self.count_files(phase["source"], phase_id)
            phase["file_count"] = count
            self.append_output(f"找到 {count} 個 {phase['name']} 需要備份\n")
            total += count
        
        self.total_files = total
        self.append_output(f"總共 {self.total_files} 個檔案需要備份\n")

    def count_files_old(self, directory, phase_id):
        """Count files matching criteria in directory"""
        try:
            expanded_dir = os.path.expanduser(directory)
            
            if not os.path.exists(expanded_dir):
                self.append_output(f"⚠️ 目錄不存在: {expanded_dir}\n")
                return 0
                
            count = 0
            selected_date = datetime.strptime(self.selected_date, "%Y-%m-%d")
            phase = self.phases[phase_id]
            
            for root, _, files in os.walk(expanded_dir):
                for file in files:
                    file_path = Path(root) / file
                    
                    try:
                        file_mtime = datetime.fromtimestamp(file_path.stat().st_mtime)
                        if file_mtime >= selected_date:
                            if self.file_matches_criteria(file_path, phase):
                                count += 1
                    except:
                        continue
            
            return count
                
        except Exception as e:
            self.append_output(f"⚠️ 計算 {directory} 檔案數量時出錯: {str(e)}\n")
            return 0

    def execute_phase(self, phase_id):
        """Execute backup phase with proper progress updates"""
        phase = self.phases[phase_id]
        self.append_output(f"\n▶️ 開始 {phase['name']} 備份...\n")
        self.progress_queue.put(('phase_start', phase['name']))
        
        try:
            phase_cfg = self.phases[phase_id]
            source_dir = os.path.expanduser(phase_cfg["source"])
            target_dir = os.path.expanduser(phase_cfg["target"]) if phase_cfg["target"] else self.get_download_dir()
            
            os.makedirs(target_dir, exist_ok=True)
            zip_path = os.path.join(target_dir, f"backup_{phase_id}_{time.strftime('%Y%m%d')}.zip")
            selected_date = datetime.strptime(self.selected_date, "%Y-%m-%d")
            
            processed_files = 0
            total_files = phase_cfg["file_count"]
            
            with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
                for root, _, files in os.walk(source_dir):
                    for file in files:
                        file_path = Path(root) / file
                        try:
                            file_mtime = datetime.fromtimestamp(file_path.stat().st_mtime)
                            if file_mtime >= selected_date and self.file_matches_criteria(file_path, phase_cfg):
                                rel_path = os.path.relpath(file_path, source_dir)
                                zipf.write(file_path, rel_path)
                                processed_files += 1
                                
                                # Calculate and send progress update
                                phase_progress = processed_files / max(total_files, 1)
                                overall_progress = sum(
                                    p["weight"] * (p["processed_in_phase"] / max(p["file_count"], 1))
                                    for p in self.phases.values()
                                )
                                self.phases[phase_id]["processed_in_phase"] = processed_files
                                self.progress_queue.put(('progress', min(overall_progress, 0.99)))
                                self.append_output(f"✓ 已壓縮: {rel_path} 進度完成{overall_progress*100}%\n")
                                
                        except Exception as e:
                            self.append_output(f"⚠️ 跳過檔案 {file_path}: {str(e)}\n")
            
            # Final update for phase completion
            self.phases[phase_id]["processed_in_phase"] = processed_files
            overall_progress = sum(
                p["weight"] * (p["processed_in_phase"] / max(p["file_count"], 1))
                for p in self.phases.values()
            )
            self.progress_queue.put(('progress', min(overall_progress, 0.99)))
            
            self.append_output(f"✅ {phase['name']} 完成 ({processed_files}/{total_files} 檔案)\n")
            
        except Exception as e:
            self.append_output(f"❌ {phase['name']} 備份失敗: {str(e)}\n")
            self.progress_queue.put(('error', f"{phase['name']} 失敗"))

    def file_matches_criteria(self, file_path, phase):
        """Optimized file matching with intelligent logging"""
        filename = file_path.name.lower()
        
        # User patterns
        user_include = [p.strip().lower() for p in phase["file_patterns"].split(",") if p.strip()]
        user_exclude = [p.strip().lower() for p in phase["exclude_patterns"].split(",") if p.strip()]
        
        # Universal exclude patterns
        universal_exclude = [
            '*.tmp', '*.temp', '*.bak', '*.backup',
            '*.swp', '~*', '*.~*', '*.log', '*.cache',
            '*.DS_Store', 'Thumbs.db', 'desktop.ini',
            '*.part', '*.download', '*.crdownload',
            '*.pid', '*.lock', '*.lck'
        ]

        # 1. Check if explicitly included first
        if user_include and "*" not in user_include:
            for pattern in user_include:
                if fnmatch.fnmatch(filename, pattern):
                    return True
            # If we have specific includes and no match
            return False

        # 2. Check excludes (user + universal)
        all_excludes = user_exclude + universal_exclude
        for pattern in all_excludes:
            if fnmatch.fnmatch(filename, pattern):
                # Only log if it's a universal exclude that wasn't in user excludes
                if pattern in universal_exclude and pattern not in user_exclude:
                    self.append_output(f"× 排除系統檔案: {filename}\n")
                return False

        # 3. If we get here, include the file
        return True

    def get_download_dir(self):
        """Get system download directory"""
        try:
            result = subprocess.run(['xdg-user-dir', 'DOWNLOAD'], 
                                  capture_output=True, 
                                  text=True)
            dest_dir = result.stdout.strip()
            if not dest_dir or not os.path.exists(dest_dir):
                dest_dir = os.path.expanduser("~/Downloads")
            
            os.makedirs(dest_dir, exist_ok=True)
            return dest_dir
        except:
            return os.path.expanduser("~/Downloads")

    def update_progress_from_queue(self):
        """Process messages from backup thread"""
        try:
            while True:
                item = self.progress_queue.get_nowait()
                
                if item[0] == 'progress':
                    GLib.idle_add(self.progress_bar.set_fraction, item[1])
                    current_phase = self.phases[self.current_phase]
                    phase_progress = sum(
                        p["weight"] * p["completed"] 
                        for p in self.phases.values()
                    )
                    GLib.idle_add(
                        self.progress_bar.set_text, 
                        f"{int(phase_progress*100)}% - {current_phase['name']} "
                        f"({current_phase['processed_in_phase']}/{current_phase['file_count']})"
                    )
                elif item[0] == 'output':
                    self.append_output(item[1])
                elif item[0] == 'phase_start':
                    GLib.idle_add(
                        self.progress_bar.set_text, 
                        f"正在 {item[1]}..."
                    )
                    self.append_output(f"\n▶️ 開始 {item[1]}...\n")
                elif item[0] == 'complete':
                    GLib.idle_add(self.progress_bar.set_fraction, 1.0)
                    GLib.idle_add(self.progress_bar.set_text, "完成")
                    self.append_output(f"\n{item[1]}\n")
                    GLib.timeout_add(5000, self.reset_progress_bar)
                elif item[0] == 'error':
                    self.append_output(f"\n{item[1]}\n")
                    GLib.idle_add(self.progress_bar.set_text, "❌ 失敗")
                    GLib.timeout_add(5000, self.reset_progress_bar)
                    
        except queue.Empty:
            pass
        
        return True  # Continue calling this method

    def append_output(self, text):
        """Add text to output console with auto-scroll"""
        def _append():
            end_iter = self.output_buffer.get_end_iter()
            self.output_buffer.insert(end_iter, text)
            
            # Auto-scroll to bottom
            mark = self.output_buffer.create_mark(None, end_iter, True)
            self.output_view.scroll_to_mark(mark, 0.0, True, 0.0, 1.0)
        
        GLib.idle_add(_append)
    
    def reset_progress_bar(self):
        """Reset progress bar after completion"""
        self.progress_bar.set_fraction(0.0)
        self.progress_bar.set_text("")
        self.progress_updater_running = False
        return False  # Stop timeout




class BackupApplication(Gtk.Application):
    def __init__(self):
        super().__init__(application_id="com.example.xubackuprunner")
       

    def do_activate(self):
        win = BackupApp(self)
        win.present()

app = BackupApplication()
app.run(None)
