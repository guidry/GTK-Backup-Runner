#!/bin/bash

set -e  # Exit on error

# Package configuration
PKG_NAME="gtk-backup-runner"
VERSION="1.0"
ARCH="all"
MAINTAINER="ZhiCheng Xu <guidryxu@gmail.com>"

# Clean previous build
rm -rf ${PKG_NAME}-deb

# Create directory structure
mkdir -p ${PKG_NAME}-deb/DEBIAN
mkdir -p ${PKG_NAME}-deb/usr/bin
mkdir -p ${PKG_NAME}-deb/usr/share/applications
mkdir -p ${PKG_NAME}-deb/usr/share/icons/hicolor/128x128/apps
mkdir -p ${PKG_NAME}-deb/usr/share/doc/${PKG_NAME}
mkdir -p ${PKG_NAME}-deb/usr/share/locale/{zh_TW,ja,ko,es,fr,de,zh_CN,th,id}/LC_MESSAGES

# Create control file
cat <<EOF > ${PKG_NAME}-deb/DEBIAN/control
Package: ${PKG_NAME}
Version: ${VERSION}
Section: utils
Priority: optional
Architecture: ${ARCH}
Depends: python3, python3-gi, gir1.2-gtk-4.0, gettext
Maintainer: ${MAINTAINER}
Description: A GTK backup program for modified files
 This package can automate backup tasks,
 including file compression and versioning.
 異動檔案備份小幫手 - 根據設定檔備份多個目錄
EOF

# Create postinst script
cat <<EOF > ${PKG_NAME}-deb/DEBIAN/postinst
#!/bin/bash
set -e
# Update desktop database
update-desktop-database || true
# Update icon cache
gtk-update-icon-cache -q -t /usr/share/icons/hicolor || true
EOF
chmod 0755 ${PKG_NAME}-deb/DEBIAN/postinst

# Create copyright file
cat <<EOF > ${PKG_NAME}-deb/usr/share/doc/${PKG_NAME}/copyright
Format: http://www.debian.org/doc/packaging-manuals/copyright-format/1.0/
Upstream-Name: ${PKG_NAME}
Source: none

Files: *
Copyright: 2025 ${MAINTAINER}
License: LGPL-3+
 This program is free software: you can redistribute it and/or modify
 it under the terms of the GNU LESSER GENERAL PUBLIC LICENSE as published by
 the Free Software Foundation, either version 3 of the License, or
 (at your option) any later version.
EOF

# Create changelog
echo "${PKG_NAME} (${VERSION}) stable; urgency=low

  * Initial multilingual release
  * Added support for 9 languages
  * Improved desktop integration

 -- ${MAINTAINER}  $(date -R)
" | gzip -9 > ${PKG_NAME}-deb/usr/share/doc/${PKG_NAME}/changelog.gz

# Copy executable and scripts
cp GTK_backup_runner.py ${PKG_NAME}-deb/usr/bin/gtk-backup-runner
cp zip_modified_db_files.sh ${PKG_NAME}-deb/usr/bin/
cp zip_modified_source_files.sh ${PKG_NAME}-deb/usr/bin/
chmod 0755 ${PKG_NAME}-deb/usr/bin/*

# Compile and install translations
for lang in zh_TW ja ko es fr de zh_CN th id; do
    po_file="${lang}.po"
    mo_dir="${PKG_NAME}-deb/usr/share/locale/${lang}/LC_MESSAGES"
    
    if [ -f "$po_file" ]; then
        mkdir -p "$mo_dir"
        msgfmt "$po_file" -o "$mo_dir/gtkbackuprunner.mo"
        echo "Compiled translation: $po_file -> $mo_dir/gtkbackuprunner.mo"
    else
        echo "Warning: Translation file $po_file not found!"
    fi
done

# Create .desktop file with multilingual support
cat <<EOF > ${PKG_NAME}-deb/usr/share/applications/${PKG_NAME}.desktop
[Desktop Entry]
Version=1.0
Type=Application
Name=GTK Backup Runner
Name[zh_TW]=GTK 異動檔案備份工具
Name[ja]=GTK 変更ファイルバックアップツール
Name[ko]=GTK 수정 파일 백업 도구
Name[es]=GTK Copia de Archivos Modificados
Name[fr]=GTK Sauvegarde de Fichiers Modifiés
Name[de]=GTK Änderungs-Backup
Name[zh_CN]=GTK 文件备份工具
Name[th]=เครื่องมือสำรองไฟล์ GTK
Name[id]=Pencadangan Berkas GTK

GenericName=Modified Files Backup Helper
GenericName[zh_TW]=異動檔案備份小幫手
GenericName[ja]=変更ファイルバックアップ支援
GenericName[ko]=수정 파일 백업 도우미
GenericName[es]=Asistente para Copia de Archivos Modificados
GenericName[fr]=Assistant de Sauvegarde des Fichiers Modifiés
GenericName[de]=Hilfsprogramm für Änderungssicherung
GenericName[zh_CN]=修改文件备份助手
GenericName[th]=ตัวช่วยสำรองไฟล์ที่ถูกแก้ไข
GenericName[id]=Pembantu Pencadangan Berkas Termodifikasi

Comment=Backup files modified since selected date
Comment[zh_TW]=備份自選日期後修改的檔案
Comment[ja]=選択した日付以降に変更されたファイルをバックアップ
Comment[ko]=선택한 날짜 이후 수정된 파일 백업
Comment[es]=Copia de seguridad de archivos modificados desde la fecha seleccionada
Comment[fr]=Sauvegarde des fichiers modifiés depuis la date sélectionnée
Comment[de]=Sicherung von seit dem gewählten Datum geänderten Dateien
Comment[zh_CN]=备份自选定日期后修改的文件
Comment[th]=สำรองไฟล์ที่ถูกแก้ไขตั้งแต่วันที่เลือก
Comment[id]=Cadangkan berkas yang dimodifikasi sejak tanggal terpilih

Exec=/usr/bin/gtk-backup-runner
Icon=gtk-backup-runner
Terminal=false
Categories=Utility;FileTools;GTK;
StartupNotify=true
Keywords=backup;files;modified;utility;
Keywords[zh_TW]=備份;檔案;異動;工具;
Keywords[ja]=バックアップ;ファイル;変更;ユーティリティ;
Keywords[ko]=백업;파일;수정;유틸리티;
Keywords[es]=copia;archivos;modificado;utilidad;
Keywords[fr]=sauvegarde;fichiers;modifié;utilitaire;
Keywords[de]=sicherung;dateien;geändert;dienstprogramm;
Keywords[zh_CN]=备份;文件;修改;工具;
Keywords[th]=สำรอง;ไฟล์;แก้ไข;เครื่องมือ;
Keywords[id]=cadangan;berkas;modifikasi;alat;
EOF

# Copy icon
cp gtk-backup-runner.png ${PKG_NAME}-deb/usr/share/icons/hicolor/128x128/apps/gtk-backup-runner.png

# Set permissions
find ${PKG_NAME}-deb -type d -exec chmod 0755 {} +
find ${PKG_NAME}-deb/usr/bin -type f -exec chmod 0755 {} +
find ${PKG_NAME}-deb/usr/share -type f -exec chmod 0644 {} +
chmod 0644 ${PKG_NAME}-deb/usr/share/applications/${PKG_NAME}.desktop

# Fix ownership (to prevent lintian warnings)
sudo chown -R root:root ${PKG_NAME}-deb

# Build the package
dpkg-deb --build ${PKG_NAME}-deb

# Rename the final package
mv ${PKG_NAME}-deb.deb ${PKG_NAME}_${VERSION}_${ARCH}.deb

echo "Package created: ${PKG_NAME}_${VERSION}_${ARCH}.deb"
