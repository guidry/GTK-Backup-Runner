import gi
import subprocess
import os
import time
from threading import Thread
import queue
import re
from datetime import datetime

gi.require_version("Gtk", "4.0")
from gi.repository import Gtk, GLib

class BashScriptRunner(Gtk.ApplicationWindow):
    def __init__(self, app):
        super().__init__(application=app, title="備份出納系統")
        self.set_default_size(500, 400)
        
        # Main vertical box
        vbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        vbox.set_margin_top(20)
        vbox.set_margin_bottom(20)
        vbox.set_margin_start(20)
        vbox.set_margin_end(20)
        
        # Title label
        title_label = Gtk.Label(label="備份出納系統檔案，會產生資料庫及程式的備份壓縮檔於「下載」資料夾")
        vbox.append(title_label)
        
        # Date picker button
        self.date_button = Gtk.Button(label="選擇日期")
        self.date_button.connect("clicked", self.open_date_picker)
        vbox.append(self.date_button)
        
        # Selected date display
        self.date_label = Gtk.Label(label="選擇的日期: 無")
        vbox.append(self.date_label)
        
        # Backup button
        self.button = Gtk.Button(label="執行備份")
        self.button.connect("clicked", self.run_scripts)
        vbox.append(self.button)
        
        # Progress bar
        self.progress_bar = Gtk.ProgressBar()
        vbox.append(self.progress_bar)
        
        # Output console
        self.output_view = Gtk.TextView()
        self.output_view.set_editable(False)
        self.output_view.set_wrap_mode(Gtk.WrapMode.WORD)
        self.output_buffer = self.output_view.get_buffer()
        
        scroll = Gtk.ScrolledWindow()
        scroll.set_child(self.output_view)
        scroll.set_min_content_height(150)
        vbox.append(scroll)
        
        self.set_child(vbox)
        
        # Progress tracking variables
        self.progress_queue = queue.Queue()
        self.progress_updater_running = False
        self.total_files = 0
        self.processed_files = 0
        self.current_phase = ""
        
        # Phase configuration with optimized weights
        self.phases = {
            "database": {
                "name": "資料庫備份",
                "weight": 0.25,
                "completed": 0.0,
                "file_count": 0,
                "find_args": ['(', '-name', '*.db', '-o', '-name', '*.sqlite', '-o', '-name', '*.sqlite3', ')']
            },
            "source": {
                "name": "程式檔案備份",
                "weight": 0.35,
                "completed": 0.0,
                "file_count": 0,
                "find_args": ['!', '-name', '*.sqlite', '!', '-name', '*.db']
            },
            "data": {
                "name": "數據檔案備份",
                "weight": 0.40,
                "completed": 0.0,
                "file_count": 0,
                "find_args": [
                    '!', '-name', '*Zone.Identifier*',
                    '!', '-name', '*.~lock.*',
                    '!', '-name', '*.tmp',
                    '!', '-name', '*.bak',
                    '!', '-name', '*.swp',
                    '!', '-name', '*.log',
                    '!', '-name', '*~',
                    '!', '-name', '.*'
                ]
            }
        }

    def open_date_picker(self, button):
        """Open calendar dialog for date selection"""
        dialog = Gtk.Dialog(title="選擇日期", transient_for=self, modal=True)
        calendar = Gtk.Calendar()
        dialog.get_content_area().append(calendar)
        
        dialog.add_button("取消", Gtk.ResponseType.CANCEL)
        dialog.add_button("確定", Gtk.ResponseType.OK)
        
        dialog.connect("response", self.on_date_selected, calendar)
        dialog.present()

    def on_date_selected(self, dialog, response_id, calendar):
        """Handle date selection from calendar"""
        if response_id == Gtk.ResponseType.OK:
            date = calendar.get_date()
            self.selected_date = f"{date.get_year():04d}-{date.get_month()+1:02d}-{date.get_day_of_month():02d}"
            self.date_label.set_text(f"選擇的日期: {self.selected_date}")
        dialog.close()

    def run_scripts(self, button):
        """Initiate backup process"""
        if not hasattr(self, "selected_date"):
            self.append_output("請選擇日期。\n")
            return
        
        # Reset all progress tracking
        self.progress_bar.set_fraction(0.0)
        self.progress_bar.set_text("準備中...")
        self.output_buffer.set_text("開始備份...\n")
        self.total_files = 0
        self.processed_files = 0
        
        for phase in self.phases.values():
            phase["completed"] = 0.0
            phase["file_count"] = 0
        
        if not self.progress_updater_running:
            GLib.timeout_add(100, self.update_progress_from_queue)
            self.progress_updater_running = True
        
        # Start backup in separate thread
        Thread(target=self.execute_backup, daemon=True).start()

    def execute_backup(self):
        """Main backup execution method"""
        try:
            # Count files first for accurate progress
            self.count_all_files()
            
            # Execute each backup phase
            for phase_name in ["database", "source", "data"]:
                self.execute_phase(phase_name)
            
            # Final completion
            self.progress_queue.put(('progress', 1.0))
            self.progress_queue.put(('complete', "🎉 備份完成！"))
        except Exception as e:
            self.progress_queue.put(('error', f"❌ 發生錯誤: {str(e)}"))

    def count_all_files(self):
        """Count files for all phases with recursive search"""
        total = 0
        
        for phase_name, phase in self.phases.items():
            if phase_name == "data":
                # Special handling for data directory with school year
                current_year = datetime.now().year
                current_month = datetime.now().month
                year_diff = (current_year - 1911) if current_month >= 8 else (current_year - 1912)
                directory = f"/DATA/公務/{year_diff}出納"
            else:
                directory = "~/public_html"
            
            count = self.count_files(directory, phase["find_args"])
            phase["file_count"] = count
            self.append_output(f"找到 {count} 個{phase['name']}需要備份\n")
            total += count
        
        self.total_files = total
        self.append_output(f"總共 {self.total_files} 個檔案需要備份\n\n")

    def count_files(self, directory, conditions):
        """Count files matching conditions in directory and all subdirectories"""
        try:
            expanded_dir = os.path.expanduser(directory)
            
            if not os.path.exists(expanded_dir):
                self.append_output(f"⚠️ 目錄不存在: {expanded_dir}\n")
                return 0
                
            # Build find command that outputs just filenames
            cmd = ['find', expanded_dir, '-type', 'f', '-newermt', self.selected_date]
            cmd.extend(conditions)
            
            # Run find command and count lines of output
            result = subprocess.run(cmd,
                                 stdout=subprocess.PIPE,
                                 stderr=subprocess.PIPE,
                                 text=True,
                                 timeout=30)
            
            # Handle output
            output = result.stdout
            stderr = result.stderr.strip()
            
            if stderr:
                self.append_output(f"⚠️ 搜尋錯誤: {stderr}\n")
            
            # Count non-empty lines
            count = len([line for line in output.split('\n') if line.strip()])
            return count
                
        except subprocess.TimeoutExpired:
            self.append_output(f"⚠️ 搜尋 {directory} 逾時 (30秒)\n")
            return 0
        except Exception as e:
            self.append_output(f"⚠️ 計算 {directory} 檔案數量時出錯: {str(e)}\n")
            return 0

    def execute_phase(self, phase_name):
        """Execute a backup phase with recursive file searching"""
        phase = self.phases[phase_name]
        self.current_phase = phase_name
        self.append_output(f"\n▶️ 開始 {phase['name']}...\n")
        
        # Special handling for data directory
        if phase_name == "data":
            current_year = datetime.now().year
            current_month = datetime.now().month
            year_diff = (current_year - 1911) if current_month >= 8 else (current_year - 1912)
            directory = f"/DATA/公務/{year_diff}出納"
        else:
            directory = "~/public_html"
        
        # Create tar.gz file in downloads folder
        dest_dir = self.get_download_dir()
        timestamp = time.strftime('%Y%m%d')
        archive_file = os.path.join(dest_dir, f"modified_{phase_name}_files_{timestamp}.tar.gz")
        
        # Build find command to get file list
        find_cmd = ['find', os.path.expanduser(directory), '-type', 'f', '-newermt', self.selected_date]
        find_cmd.extend(phase["find_args"])
        find_cmd.extend(['-print0'])  # Use null-terminated names
        
        # Build tar command - simplified and more robust
        tar_cmd = ['tar', '-czf', archive_file, '--null', '--files-from=-']
        
        self.append_output(f"執行命令: {' '.join(find_cmd)} | {' '.join(tar_cmd)}\n")
        self.run_tar_command(find_cmd, tar_cmd, phase)

    def run_tar_command(self, find_cmd, tar_cmd, phase):
        """Execute tar command with proper progress tracking"""
        try:
            # Create the pipes
            find_process = subprocess.Popen(find_cmd,
                                          stdout=subprocess.PIPE,
                                          stderr=subprocess.PIPE)
            
            tar_process = subprocess.Popen(tar_cmd,
                                         stdin=find_process.stdout,
                                         stdout=subprocess.PIPE,
                                         stderr=subprocess.PIPE,
                                         text=True,
                                         bufsize=1,
                                         universal_newlines=True)
            
            # Close find's stdout as it's connected to tar's stdin
            find_process.stdout.close()
            
            files_processed = 0
            total_files = phase["file_count"]
            
            # Immediately update progress to show phase has started
            phase["completed"] = 0.01
            total_progress = sum(p["weight"] * p["completed"] for p in self.phases.values())
            self.progress_queue.put(('progress', min(total_progress, 0.99)))
            
            # Read stderr separately to capture progress
            stderr_reader = Thread(target=self.read_stderr, args=(tar_process.stderr,))
            stderr_reader.daemon = True
            stderr_reader.start()
            
            # Read stdout line by line
            while True:
                output = tar_process.stdout.readline()
                if not output and tar_process.poll() is not None:
                    break
                if output:
                    files_processed += 1
                    self.processed_files += 1
                    phase["completed"] = min(files_processed / max(total_files, 1), 1.0)
                    total_progress = sum(p["weight"] * p["completed"] for p in self.phases.values())
                    self.progress_queue.put(('progress', min(total_progress, 0.99)))
                    self.append_output(f"處理 {phase['name']} 文件 {files_processed}/{phase['file_count']}\n")
            
            # Wait for completion
            returncode = tar_process.wait()
            stderr_reader.join()
            
            # Ensure phase shows as complete
            phase["completed"] = 1.0
            total_progress = sum(p["weight"] * p["completed"] for p in self.phases.values())
            self.progress_queue.put(('progress', min(total_progress, 0.99)))
            
            # Report completion
            files_processed = max(files_processed, total_files)
            self.append_output(f"✅ {phase['name']}完成 (處理 {files_processed}/{phase['file_count']} 個檔案, 返回代碼: {returncode})\n")
                
            if returncode != 0:
                self.progress_queue.put(('error', f"{phase['name']} 失敗"))
                    
        except Exception as e:
            self.append_output(f"❌ 執行 {phase['name']} 時發生嚴重錯誤: {str(e)}\n")
            self.progress_queue.put(('error', f"{phase['name']} 失敗"))

    def read_stderr(self, stderr):
        """Read stderr in separate thread"""
        while True:
            error = stderr.readline()
            if not error:
                break
            self.append_output(f"⚠️ {error.strip()}\n")

    def get_download_dir(self):
        """Get system download directory"""
        try:
            result = subprocess.run(['xdg-user-dir', 'DOWNLOAD'], 
                                  capture_output=True, 
                                  text=True)
            dest_dir = result.stdout.strip()
            if not dest_dir or not os.path.exists(dest_dir):
                dest_dir = os.path.expanduser("~/Downloads")
            
            os.makedirs(dest_dir, exist_ok=True)
            return dest_dir
        except:
            return os.path.expanduser("~/Downloads")

    def update_progress_from_queue(self):
        """Process messages from backup thread"""
        try:
            while True:
                item = self.progress_queue.get_nowait()
                
                if item[0] == 'progress':
                    GLib.idle_add(self.progress_bar.set_fraction, item[1])
                    GLib.idle_add(self.progress_bar.set_text, f"{int(item[1]*100)}%")
                elif item[0] == 'output':
                    self.append_output(item[1])
                elif item[0] == 'phase_start':
                    self.append_output(f"\n▶️ 開始 {item[1]}...\n")
                    GLib.idle_add(self.progress_bar.set_text, f"正在 {item[1]}...")
                elif item[0] == 'complete':
                    GLib.idle_add(self.progress_bar.set_fraction, 1.0)
                    GLib.idle_add(self.progress_bar.set_text, "完成")
                    self.append_output(f"\n{item[1]}\n")
                    GLib.timeout_add(5000, self.reset_progress_bar)
                elif item[0] == 'error':
                    self.append_output(f"\n{item[1]}\n")
                    GLib.idle_add(self.progress_bar.set_text, "❌ 失敗")
                    GLib.timeout_add(5000, self.reset_progress_bar)
                    
        except queue.Empty:
            pass
        
        return True  # Continue calling this method

    def append_output(self, text):
        """Add text to output console with auto-scroll"""
        def _append():
            end_iter = self.output_buffer.get_end_iter()
            self.output_buffer.insert(end_iter, text)
            
            # Auto-scroll to bottom
            mark = self.output_buffer.create_mark(None, end_iter, True)
            self.output_view.scroll_to_mark(mark, 0.0, True, 0.0, 1.0)
        
        GLib.idle_add(_append)
    
    def reset_progress_bar(self):
        """Reset progress bar after completion"""
        self.progress_bar.set_fraction(0.0)
        self.progress_bar.set_text("")
        self.progress_updater_running = False
        return False  # Stop timeout

class BashRunnerApp(Gtk.Application):
    def __init__(self):
        super().__init__(application_id="com.example.bashrunner")

    def do_activate(self):
        win = BashScriptRunner(self)
        win.present()

app = BashRunnerApp()
app.run(None)
