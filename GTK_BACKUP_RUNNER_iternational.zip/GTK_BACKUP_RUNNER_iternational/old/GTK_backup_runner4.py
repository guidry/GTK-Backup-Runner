import gi
import subprocess
import os
import time
from threading import Thread
import queue
import re
from datetime import datetime

gi.require_version("Gtk", "4.0")
from gi.repository import Gtk, GLib

class BashScriptRunner(Gtk.ApplicationWindow):
    def __init__(self, app):
        super().__init__(application=app, title="備份出納系統")
        self.set_default_size(500, 400)
        
        vbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        vbox.set_margin_top(20)
        vbox.set_margin_bottom(20)
        vbox.set_margin_start(20)
        vbox.set_margin_end(20)
        
        # Title label
        title_label = Gtk.Label(label="備份出納系統檔案，會產生資料庫及程式的備份壓縮檔於「下載」資料夾")
        vbox.append(title_label)
        
        # Date picker
        self.date_button = Gtk.Button(label="選擇日期")
        self.date_button.connect("clicked", self.open_date_picker)
        vbox.append(self.date_button)
        
        self.date_label = Gtk.Label(label="選擇的日期: 無")
        vbox.append(self.date_label)
        
        self.button = Gtk.Button(label="執行備份")
        self.button.connect("clicked", self.run_scripts)
        vbox.append(self.button)
        
        # Progress bar
        self.progress_bar = Gtk.ProgressBar()
        vbox.append(self.progress_bar)
        
        self.output_view = Gtk.TextView()
        self.output_view.set_editable(False)
        self.output_view.set_wrap_mode(Gtk.WrapMode.WORD)
        self.output_buffer = self.output_view.get_buffer()
        
        scroll = Gtk.ScrolledWindow()
        scroll.set_child(self.output_view)
        scroll.set_min_content_height(150)
        vbox.append(scroll)
        
        self.set_child(vbox)
        
        # Progress tracking
        self.progress_queue = queue.Queue()
        self.progress_updater_running = False
        self.total_files = 0
        self.processed_files = 0
        self.current_phase = ""
        self.phase_weights = {
            "database": 0.25,
            "source": 0.35,
            "data": 0.40
        }

    def open_date_picker(self, button):
        dialog = Gtk.Dialog(title="選擇日期", transient_for=self, modal=True)
        calendar = Gtk.Calendar()
        dialog.get_content_area().append(calendar)
        
        dialog.add_button("取消", Gtk.ResponseType.CANCEL)
        ok_button = dialog.add_button("確定", Gtk.ResponseType.OK)
        
        dialog.connect("response", self.on_date_selected, calendar)
        
        dialog.present()
        
    def on_date_selected(self, dialog, response_id, calendar):
        if response_id == Gtk.ResponseType.OK:
            date = calendar.get_date()
            year = date.get_year()
            month = date.get_month() + 1  # Gtk.Calendar months are 0-based
            day = date.get_day_of_month()
            self.selected_date = f"{year:04d}-{month:02d}-{day:02d}"
            self.date_label.set_text(f"選擇的日期: {self.selected_date}")
        dialog.close()
        
    def run_scripts(self, button):
        if not hasattr(self, "selected_date"):
            self.output_buffer.set_text("請選擇日期。")
            return
        
        self.progress_bar.set_fraction(0.0)
        self.progress_bar.set_text("準備中...")
        self.output_buffer.set_text("開始備份...\n")
        self.total_files = 0
        self.processed_files = 0
        
        if not self.progress_updater_running:
            GLib.timeout_add(100, self.update_progress_from_queue)
            self.progress_updater_running = True
        
        thread = Thread(target=self.execute_backup)
        thread.daemon = True
        thread.start()
    
    def execute_backup(self):
        try:
            # Count all files first for accurate progress
            self.count_all_files()
            
            # Execute each backup phase
            self.backup_database_files()
            self.backup_source_files()
            self.backup_data_files()
            
            self.progress_queue.put(('progress', 1.0))
            self.progress_queue.put(('complete', "🎉 備份完成！"))
        except Exception as e:
            self.progress_queue.put(('error', f"❌ 發生錯誤: {str(e)}"))

    def count_all_files(self):
        """Count all files that will be processed in each phase"""
        total = 0
        
        # Database files count
        db_files = self.count_files(
            "~/public_html",
            ['-name "*.db"', '-o', '-name "*.sqlite"', '-o', '-name "*.sqlite3"']
        )
        self.progress_queue.put(('output', 
            f"找到 {db_files} 個資料庫檔案需要備份\n"))
        total += db_files
        
        # Source files count (excluding database files)
        source_files = self.count_files(
            "~/public_html",
            ['!', '-name "*.sqlite"', '!', '-name "*.db"']
        )
        self.progress_queue.put(('output',
            f"找到 {source_files} 個程式檔案需要備份\n"))
        total += source_files
        
        # Data files count (with exclusions)
        # Calculate school year directory for data files
        current_year = datetime.now().year
        current_month = datetime.now().month
        year_diff = (current_year - 1911) if current_month >= 8 else (current_year - 1912)
        data_dir = f"/DATA/公務/{year_diff}出納"
        
        data_files = self.count_files(
            data_dir,
            [
                '!', '-name "*Zone.Identifier*"',
                '!', '-name "*.~lock.*"',
                '!', '-name "*.tmp"',
                '!', '-name "*.bak"',
                '!', '-name "*.swp"',
                '!', '-name "*.log"',
                '!', '-name "*~"',
                '!', '-name ".*"'
            ]
        )
        self.progress_queue.put(('output',
            f"找到 {data_files} 個數據檔案需要備份\n"))
        total += data_files
        
        self.total_files = total
        self.progress_queue.put(('output',
            f"總共 {self.total_files} 個檔案需要備份\n\n"))

    def count_files(self, directory, conditions):
        """Count files matching conditions in directory"""
        try:
            # Expand ~ in directory path
            expanded_dir = os.path.expanduser(directory)
            
            # Skip if directory doesn't exist
            if not os.path.exists(expanded_dir):
                return 0
                
            find_cmd = [
                'find', expanded_dir,
                '-type', 'f',
                '-newermt', self.selected_date
            ] + conditions + ['|', 'wc', '-l']
            
            result = subprocess.run(' '.join(find_cmd), 
                                  shell=True, 
                                  capture_output=True, 
                                  text=True)
            return int(result.stdout.strip())
        except Exception as e:
            self.progress_queue.put(('output', f"⚠️ 計算檔案數量時出錯: {str(e)}\n"))
            return 0

    def backup_database_files(self):
        """Execute database files backup"""
        self.current_phase = "database"
        self.progress_queue.put(('phase_start', "資料庫備份"))
        
        dest_dir = self.get_download_dir()
        zip_file = os.path.join(dest_dir, f"modified_database_files_{time.strftime('%Y%m%d')}.zip")
        find_cmd = [
            'find', os.path.expanduser("~/public_html"),
            '-type', 'f',
            '-newermt', self.selected_date,
            '(', '-name', '"*.db"', '-o', '-name', '"*.sqlite"', '-o', '-name', '"*.sqlite3"', ')',
            '|', 'zip', zip_file, '-@'
        ]
        
        self.run_zip_command(find_cmd)

    def backup_source_files(self):
        """Execute source files backup"""
        self.current_phase = "source"
        self.progress_queue.put(('phase_start', "程式檔案備份"))
        
        dest_dir = self.get_download_dir()
        zip_file = os.path.join(dest_dir, f"modified_source_files_{time.strftime('%Y%m%d')}.zip")
        find_cmd = [
            'find', os.path.expanduser("~/public_html"),
            '-type', 'f',
            '-newermt', self.selected_date,
            '!', '-name', '"*.sqlite"',
            '!', '-name', '"*.db"',
            '|', 'zip', zip_file, '-@'
        ]
        
        self.run_zip_command(find_cmd)

    def backup_data_files(self):
        """Execute data files backup"""
        self.current_phase = "data"
        self.progress_queue.put(('phase_start', "數據檔案備份"))
        
        # Calculate school year directory
        current_year = datetime.now().year
        current_month = datetime.now().month
        year_diff = (current_year - 1911) if current_month >= 8 else (current_year - 1912)
        data_dir = f"/DATA/公務/{year_diff}出納"
        
        dest_dir = self.get_download_dir()
        zip_file = os.path.join(dest_dir, f"modified_DATA_files_{time.strftime('%Y%m%d')}.zip")
        find_cmd = [
            'find', data_dir,
            '-type', 'f',
            '-newermt', self.selected_date,
            '!', '-name', '"*Zone.Identifier*"',
            '!', '-name', '"*.~lock.*"',
            '!', '-name', '"*.tmp"',
            '!', '-name', '"*.bak"',
            '!', '-name', '"*.swp"',
            '!', '-name', '"*.log"',
            '!', '-name', '"*~"',
            '!', '-name', '"."',
            '|', 'zip', zip_file, '-@'
        ]
        
        self.run_zip_command(find_cmd)

    def get_download_dir(self):
        """Get the system's download directory"""
        try:
            result = subprocess.run(['xdg-user-dir', 'DOWNLOAD'], 
                                  capture_output=True, 
                                  text=True)
            dest_dir = result.stdout.strip()
            if not dest_dir or not os.path.exists(dest_dir):
                dest_dir = os.path.expanduser("~/Downloads")
            
            # Create directory if it doesn't exist
            os.makedirs(dest_dir, exist_ok=True)
            return dest_dir
        except:
            return os.path.expanduser("~/Downloads")

    def run_zip_command(self, command):
        """Execute zip command with progress tracking"""
        process = subprocess.Popen(' '.join(command),
                                 shell=True,
                                 stdout=subprocess.PIPE,
                                 stderr=subprocess.PIPE,
                                 text=True,
                                 bufsize=1,
                                 universal_newlines=True)
        
        while True:
            output = process.stdout.readline()
            if output == '' and process.poll() is not None:
                break
            if output:
                # Update progress for each file added to zip
                if "adding:" in output.lower():
                    self.processed_files += 1
                    progress = min(
                        (self.processed_files / self.total_files) if self.total_files > 0 else 0,
                        0.99  # Cap at 99% until all phases complete
                    )
                    self.progress_queue.put(('progress', progress))
                self.progress_queue.put(('output', output))
        
        # Add final output
        self.progress_queue.put(('output', 
            f"✅ {self.current_phase}備份完成 (返回代碼: {process.returncode})\n"))
        if process.returncode != 0:
            self.progress_queue.put(('output', 
                f"⚠️ 錯誤輸出: {process.stderr.read()}\n"))

    def update_progress_from_queue(self):
        try:
            while True:
                item = self.progress_queue.get_nowait()
                if item[0] == 'progress':
                    self.smooth_progress_update(item[1])
                elif item[0] == 'output':
                    GLib.idle_add(self.append_output, item[1])
                elif item[0] == 'phase_start':
                    GLib.idle_add(self.append_output, f"\n▶️ 開始 {item[1]}...\n")
                elif item[0] == 'complete':
                    GLib.idle_add(self.smooth_progress_update, 1.0)
                    GLib.idle_add(self.append_output, f"\n{item[1]}\n")
                    GLib.timeout_add(5000, self.reset_progress_bar)
                elif item[0] == 'error':
                    GLib.idle_add(self.append_output, f"\n{item[1]}\n")
                    GLib.idle_add(self.progress_bar.set_text, "❌ 失敗")
                    GLib.timeout_add(5000, self.reset_progress_bar)
        except queue.Empty:
            pass
        
        return True  # Keep the timeout running
    
    def smooth_progress_update(self, target):
        current = self.progress_bar.get_fraction()
        step = (target - current) / 5.0  # 5-step animation
        
        def update():
            nonlocal current
            current += step
            if (step > 0 and current >= target) or (step < 0 and current <= target):
                current = target
            self.progress_bar.set_fraction(current)
            if current != target:
                GLib.timeout_add(50, update)
        
        update()

    def append_output(self, text):
        end_iter = self.output_buffer.get_end_iter()
        self.output_buffer.insert(end_iter, text)
        
        # Auto-scroll to the end
        mark = self.output_buffer.create_mark(None, end_iter, True)
        self.output_view.scroll_to_mark(mark, 0.0, True, 0.0, 1.0)
    
    def reset_progress_bar(self):
        self.progress_bar.set_fraction(0.0)
        self.progress_bar.set_text("")
        self.progress_updater_running = False
        return False

class BashRunnerApp(Gtk.Application):
    def __init__(self):
        super().__init__(application_id="com.example.bashrunner")

    def do_activate(self):
        win = BashScriptRunner(self)
        win.present()

app = BashRunnerApp()
app.run(None)
