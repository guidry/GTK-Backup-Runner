import gi
import subprocess
import os
import time
from threading import Thread
import queue
from datetime import datetime

gi.require_version("Gtk", "4.0")
from gi.repository import Gtk, GLib

class BashScriptRunner(Gtk.ApplicationWindow):
    def __init__(self, app):
        super().__init__(application=app, title="備份出納系統")
        self.set_default_size(500, 400)
        
        # Main vertical box
        vbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        vbox.set_margin_top(20)
        vbox.set_margin_bottom(20)
        vbox.set_margin_start(20)
        vbox.set_margin_end(20)
        
        # Title label
        title_label = Gtk.Label(label="備份出納系統檔案，會產生資料庫及程式的備份壓縮檔於「下載」資料夾")
        vbox.append(title_label)
        
        # Date picker button
        self.date_button = Gtk.Button(label="選擇日期")
        self.date_button.connect("clicked", self.open_date_picker)
        vbox.append(self.date_button)
        
        # Selected date display
        self.date_label = Gtk.Label(label="選擇的日期: 無")
        vbox.append(self.date_label)
        
        # Backup button
        self.button = Gtk.Button(label="執行備份")
        self.button.connect("clicked", self.run_scripts)
        vbox.append(self.button)
        
        # Progress bar
        self.progress_bar = Gtk.ProgressBar()
        vbox.append(self.progress_bar)
        
        # Output console
        self.output_view = Gtk.TextView()
        self.output_view.set_editable(False)
        self.output_view.set_wrap_mode(Gtk.WrapMode.WORD)
        self.output_buffer = self.output_view.get_buffer()
        
        scroll = Gtk.ScrolledWindow()
        scroll.set_child(self.output_view)
        scroll.set_min_content_height(150)
        vbox.append(scroll)
        
        self.set_child(vbox)
        
        # Progress tracking
        self.progress_queue = queue.Queue()
        self.total_files = 0
        self.processed_files = 0
        self.current_phase = ""
        self.phases = [
            {"name": "資料庫備份", "weight": 0.25, "file_count": 0},
            {"name": "程式檔案備份", "weight": 0.35, "file_count": 0},
            {"name": "數據檔案備份", "weight": 0.40, "file_count": 0}
        ]

    def open_date_picker(self, button):
        dialog = Gtk.Dialog(title="選擇日期", transient_for=self, modal=True)
        calendar = Gtk.Calendar()
        dialog.get_content_area().append(calendar)
        dialog.add_button("取消", Gtk.ResponseType.CANCEL)
        dialog.add_button("確定", Gtk.ResponseType.OK)
        dialog.connect("response", self.on_date_selected, calendar)
        dialog.present()

    def on_date_selected(self, dialog, response_id, calendar):
        if response_id == Gtk.ResponseType.OK:
            date = calendar.get_date()
            self.selected_date = f"{date.get_year():04d}-{date.get_month()+1:02d}-{date.get_day_of_month():02d}"
            self.date_label.set_text(f"選擇的日期: {self.selected_date}")
        dialog.close()

    def run_scripts(self, button):
        if not hasattr(self, "selected_date"):
            self.output_buffer.set_text("請選擇日期。")
            return
        
        self.progress_bar.set_fraction(0.0)
        self.progress_bar.set_text("準備中...")
        self.output_buffer.set_text("開始備份...\n")
        self.total_files = 0
        self.processed_files = 0
        
        # Start progress updater
        GLib.timeout_add(100, self.update_progress_from_queue)
        
        # Start backup in separate thread
        Thread(target=self.execute_backup, daemon=True).start()

    def execute_backup(self):
        try:
            # Count files first
            self.count_all_files()
            
            # Execute each phase
            for phase in self.phases:
                self.current_phase = phase["name"]
                self.progress_queue.put(('output', f"\n▶️ 開始 {phase['name']}...\n"))
                
                # Simulate work - replace with actual backup commands
                for i in range(phase["file_count"]):
                    time.sleep(0.01)  # Simulate file processing
                    self.processed_files += 1
                    progress = self.processed_files / self.total_files
                    self.progress_queue.put(('progress', progress))
                    self.progress_queue.put(('output', f"處理文件 {i+1}/{phase['file_count']}\n"))
                
                self.progress_queue.put(('output', f"✅ {phase['name']}完成\n"))
            
            self.progress_queue.put(('progress', 1.0))
            self.progress_queue.put(('output', "\n🎉 備份完成！\n"))
        except Exception as e:
            self.progress_queue.put(('error', f"❌ 發生錯誤: {str(e)}"))

    def count_all_files(self):
        # Simulate file counting - replace with actual counting
        self.phases[0]["file_count"] = 82
        self.phases[1]["file_count"] = 3397
        self.phases[2]["file_count"] = 29
        self.total_files = sum(phase["file_count"] for phase in self.phases)
        
        for phase in self.phases:
            self.progress_queue.put(('output', f"找到 {phase['file_count']} 個{phase['name']}需要備份\n"))
        self.progress_queue.put(('output', f"總共 {self.total_files} 個檔案需要備份\n\n"))

    def update_progress_from_queue(self):
        try:
            while True:
                item = self.progress_queue.get_nowait()
                
                if item[0] == 'progress':
                    self.progress_bar.set_fraction(item[1])
                    self.progress_bar.set_text(f"{int(item[1]*100)}%")
                elif item[0] == 'output':
                    end_iter = self.output_buffer.get_end_iter()
                    self.output_buffer.insert(end_iter, item[1])
                elif item[0] == 'error':
                    self.append_output(f"\n{item[1]}\n")
                    self.progress_bar.set_text("❌ 失敗")
                    
        except queue.Empty:
            pass
        
        return True

class BashRunnerApp(Gtk.Application):
    def __init__(self):
        super().__init__(application_id="com.example.bashrunner")

    def do_activate(self):
        win = BashScriptRunner(self)
        win.present()

app = BashRunnerApp()
app.run(None)
