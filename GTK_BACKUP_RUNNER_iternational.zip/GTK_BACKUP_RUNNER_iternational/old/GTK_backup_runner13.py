import gi
import subprocess
import os
import time
from threading import Thread
import queue
from datetime import datetime

gi.require_version("Gtk", "4.0")
from gi.repository import Gtk, GLib

class BashScriptRunner(Gtk.ApplicationWindow):
    def __init__(self, app):
        super().__init__(application=app, title="備份出納系統")
        self.set_default_size(500, 400)
        
        # Main vertical box
        vbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        vbox.set_margin_top(20)
        vbox.set_margin_bottom(20)
        vbox.set_margin_start(20)
        vbox.set_margin_end(20)
        
        # Title label
        title_label = Gtk.Label(label="備份出納系統檔案，會產生資料庫及程式的備份壓縮檔於「下載」資料夾")
        vbox.append(title_label)
        
        # Date picker button
        self.date_button = Gtk.Button(label="選擇日期")
        self.date_button.connect("clicked", self.open_date_picker)
        vbox.append(self.date_button)
        
        # Selected date display
        self.date_label = Gtk.Label(label="選擇的日期: 無")
        vbox.append(self.date_label)
        
        # Backup button
        self.button = Gtk.Button(label="執行備份")
        self.button.connect("clicked", self.run_scripts)
        vbox.append(self.button)
        
        # Progress bar
        self.progress_bar = Gtk.ProgressBar()
        vbox.append(self.progress_bar)
        
        # Output console
        self.output_view = Gtk.TextView()
        self.output_view.set_editable(False)
        self.output_view.set_wrap_mode(Gtk.WrapMode.WORD)
        self.output_buffer = self.output_view.get_buffer()
        
        scroll = Gtk.ScrolledWindow()
        scroll.set_child(self.output_view)
        scroll.set_min_content_height(150)
        vbox.append(scroll)
        
        self.set_child(vbox)
        
        # Progress tracking
        self.progress_queue = queue.Queue()
        self.total_files = 0
        self.processed_files = 0
        self.current_phase = ""
        self.phases = [
            {
                "name": "資料庫備份",
                "file_count": 0,
                "find_args": ['(', '-name', '*.db', '-o', '-name', '*.sqlite', '-o', '-name', '*.sqlite3', ')'],
                "directory": "~/public_html"
            },
            {
                "name": "程式檔案備份",
                "file_count": 0,
                "find_args": ['!', '-name', '*.sqlite', '!', '-name', '*.db'],
                "directory": "~/public_html"
            },
            {
                "name": "數據檔案備份",
                "file_count": 0,
                "find_args": [
                    '!', '-name', '*Zone.Identifier*',
                    '!', '-name', '*.~lock.*',
                    '!', '-name', '*.tmp',
                    '!', '-name', '*.bak',
                    '!', '-name', '*.swp',
                    '!', '-name', '*.log',
                    '!', '-name', '*~',
                    '!', '-name', '.*'
                ],
                "directory": self.get_data_directory()
            }
        ]

    def get_data_directory(self):
        current_year = datetime.now().year
        current_month = datetime.now().month
        year_diff = (current_year - 1911) if current_month >= 8 else (current_year - 1912)
        return f"/DATA/公務/{year_diff}出納"

    def open_date_picker(self, button):
        # Create a dialog using modern GTK4 approach
        dialog = Gtk.Dialog(modal=True)
        dialog.set_title("選擇日期")
        dialog.set_transient_for(self)
        
        # Create header bar for dialog buttons
        header = Gtk.HeaderBar()
        dialog.set_titlebar(header)
        
        # Create calendar widget
        calendar = Gtk.Calendar()
        dialog.set_child(calendar)
        
        # Add buttons using modern approach
        cancel_btn = Gtk.Button(label="取消")
        cancel_btn.connect("clicked", lambda *_: dialog.close())
        header.pack_start(cancel_btn)
        
        ok_btn = Gtk.Button(label="確定")
        ok_btn.connect("clicked", self.on_date_selected, dialog, calendar)
        ok_btn.add_css_class("suggested-action")
        header.pack_end(ok_btn)
        
        dialog.present()

    def on_date_selected(self, button, dialog, calendar):
        date = calendar.get_date()
        self.selected_date = f"{date.get_year():04d}-{date.get_month()+1:02d}-{date.get_day_of_month():02d}"
        self.date_label.set_text(f"選擇的日期: {self.selected_date}")
        dialog.close()

    def run_scripts(self, button):
        if not hasattr(self, "selected_date"):
            self.output_buffer.set_text("請選擇日期。")
            return
        
        self.progress_bar.set_fraction(0.0)
        self.progress_bar.set_text("準備中...")
        self.output_buffer.set_text("開始備份...\n")
        self.total_files = 0
        self.processed_files = 0
        
        # Start progress updater
        GLib.timeout_add(100, self.update_progress_from_queue)
        
        # Start backup in separate thread
        Thread(target=self.execute_backup, daemon=True).start()

    def execute_backup(self):
        try:
            # Count files first
            self.count_all_files()
            
            # Execute each phase
            for phase in self.phases:
                self.current_phase = phase["name"]
                self.progress_queue.put(('output', f"\n▶️ 開始 {phase['name']}...\n"))
                
                # Get destination zip file
                dest_dir = self.get_download_dir()
                zip_file = os.path.join(dest_dir, f"modified_{phase['name']}_files_{time.strftime('%Y%m%d')}.zip")
                
                # Build find command
                find_cmd = ['find', os.path.expanduser(phase["directory"]), 
                           '-type', 'f', '-newermt', self.selected_date]
                find_cmd.extend(phase["find_args"])
                find_cmd.extend(['-exec', 'zip', '-v', '-q', zip_file, '{}', '+'])
                
                # Execute command
                self.run_zip_command(find_cmd, phase)
            
            self.progress_queue.put(('progress', 1.0))
            self.progress_queue.put(('output', "\n🎉 備份完成！\n"))
        except Exception as e:
            self.progress_queue.put(('error', f"❌ 發生錯誤: {str(e)}"))

    def count_all_files(self):
        self.total_files = 0
        for phase in self.phases:
            phase["file_count"] = self.count_files(phase["directory"], phase["find_args"])
            self.total_files += phase["file_count"]
            self.progress_queue.put(('output', f"找到 {phase['file_count']} 個{phase['name']}需要備份\n"))
        self.progress_queue.put(('output', f"總共 {self.total_files} 個檔案需要備份\n\n"))

    def count_files(self, directory, conditions):
        try:
            expanded_dir = os.path.expanduser(directory)
            if not os.path.exists(expanded_dir):
                self.progress_queue.put(('output', f"⚠️ 目錄不存在: {expanded_dir}\n"))
                return 0
                
            cmd = ['find', expanded_dir, '-type', 'f', '-newermt', self.selected_date]
            cmd.extend(conditions)
            
            result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
            
            if result.stderr.strip():
                self.progress_queue.put(('output', f"⚠️ 搜尋錯誤: {result.stderr.strip()}\n"))
            
            return len([line for line in result.stdout.split('\n') if line.strip()])
                
        except Exception as e:
            self.progress_queue.put(('output', f"⚠️ 計算檔案數量時出錯: {str(e)}\n"))
            return 0

    def run_zip_command(self, command, phase):
        try:
            process = subprocess.Popen(command,
                                    stdout=subprocess.PIPE,
                                    stderr=subprocess.PIPE,
                                    text=True,
                                    bufsize=1,
                                    universal_newlines=True)
            
            files_processed = 0
            while True:
                output = process.stdout.readline()
                if output == '' and process.poll() is not None:
                    break
                    
                if output:
                    # Update progress for each file processed
                    if any(x in output.lower() for x in ["adding:", "updating:", "freshening:"]):
                        files_processed += 1
                        self.processed_files += 1
                        progress = float(self.processed_files) / float(self.total_files)
                        self.progress_queue.put(('progress', progress))
                        self.progress_queue.put(('output', f"處理文件 {files_processed}/{phase['file_count']}\n"))
            
            # Ensure we account for all files
            remaining = phase["file_count"] - files_processed
            if remaining > 0:
                self.processed_files += remaining
                progress = float(self.processed_files) / float(self.total_files)
                self.progress_queue.put(('progress', progress))
            
            returncode = process.poll()
            if returncode is None:
                process.terminate()
                returncode = -1
            
            self.progress_queue.put(('output', f"✅ {phase['name']}完成 (處理 {phase['file_count']} 個檔案, 返回代碼: {returncode})\n"))
            
            if returncode != 0:
                error_output = process.stderr.read()
                if error_output:
                    self.progress_queue.put(('output', f"⚠️ 錯誤輸出: {error_output}\n"))
                self.progress_queue.put(('error', f"{phase['name']} 失敗"))
                    
        except Exception as e:
            self.progress_queue.put(('output', f"❌ 執行 {phase['name']} 時發生嚴重錯誤: {str(e)}\n"))
            self.progress_queue.put(('error', f"{phase['name']} 失敗"))

    def get_download_dir(self):
        try:
            result = subprocess.run(['xdg-user-dir', 'DOWNLOAD'], 
                                  capture_output=True, 
                                  text=True)
            dest_dir = result.stdout.strip()
            if not dest_dir or not os.path.exists(dest_dir):
                dest_dir = os.path.expanduser("~/Downloads")
            os.makedirs(dest_dir, exist_ok=True)
            return dest_dir
        except:
            return os.path.expanduser("~/Downloads")

    def update_progress_from_queue(self):
        try:
            while True:
                item = self.progress_queue.get_nowait()
                
                if item[0] == 'progress':
                    current = float(self.progress_bar.get_fraction())
                    target = float(item[1])
                    step = (target - current) / 5.0  # 5-step animation
                    
                    def update():
                        nonlocal current
                        current += step
                        if (step > 0 and current >= target) or (step < 0 and current <= target):
                            current = target
                        self.progress_bar.set_fraction(current)
                        self.progress_bar.set_text(f"{int(current*100)}%")
                        if current != target:
                            GLib.timeout_add(50, update)
                    
                    update()
                elif item[0] == 'output':
                    end_iter = self.output_buffer.get_end_iter()
                    self.output_buffer.insert(end_iter, item[1])
                elif item[0] == 'error':
                    self.append_output(f"\n{item[1]}\n")
                    self.progress_bar.set_text("❌ 失敗")
                    
        except queue.Empty:
            pass
        
        return True

    def append_output(self, text):
        end_iter = self.output_buffer.get_end_iter()
        self.output_buffer.insert(end_iter, text)
        mark = self.output_buffer.create_mark(None, end_iter, True)
        self.output_view.scroll_to_mark(mark, 0.0, True, 0.0, 1.0)

class BashRunnerApp(Gtk.Application):
    def __init__(self):
        super().__init__(application_id="com.example.bashrunner")

    def do_activate(self):
        win = BashScriptRunner(self)
        win.present()

app = BashRunnerApp()
app.run(None)
