import gi
import subprocess
import os
import time
from threading import Thread

gi.require_version("Gtk", "4.0")
from gi.repository import Gtk, GLib

class BashScriptRunner(Gtk.ApplicationWindow):
    def __init__(self, app):
        super().__init__(application=app, title="備份出納系統")
        self.set_default_size(500, 400)
        
        vbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        vbox.set_margin_top(20)
        vbox.set_margin_bottom(20)
        vbox.set_margin_start(20)
        vbox.set_margin_end(20)
        
        # Title label
        title_label = Gtk.Label(label="備份出納系統檔案，會產生資料庫及程式的備份壓縮檔於「下載」資料夾")
        vbox.append(title_label)
        
        # Date picker
        self.date_button = Gtk.Button(label="選擇日期")
        self.date_button.connect("clicked", self.open_date_picker)
        vbox.append(self.date_button)
        
        self.date_label = Gtk.Label(label="選擇的日期: 無")
        vbox.append(self.date_label)
        
        self.button = Gtk.Button(label="執行備份")
        self.button.connect("clicked", self.run_scripts)
        vbox.append(self.button)
        
        # Progress bar
        self.progress_bar = Gtk.ProgressBar()
        vbox.append(self.progress_bar)
        
        self.output_view = Gtk.TextView()
        self.output_view.set_editable(False)
        self.output_view.set_wrap_mode(Gtk.WrapMode.WORD)
        self.output_buffer = self.output_view.get_buffer()
        
        scroll = Gtk.ScrolledWindow()
        scroll.set_child(self.output_view)
        scroll.set_min_content_height(150)
        vbox.append(scroll)
        
        self.set_child(vbox)
        
    def open_date_picker(self, button):
        dialog = Gtk.Dialog(title="選擇日期", transient_for=self, modal=True)
        calendar = Gtk.Calendar()
        dialog.get_content_area().append(calendar)
        
        dialog.add_button("取消", Gtk.ResponseType.CANCEL)
        ok_button = dialog.add_button("確定", Gtk.ResponseType.OK)
        
        dialog.connect("response", self.on_date_selected, calendar)
        
        dialog.present()
        
    def on_date_selected(self, dialog, response_id, calendar):
        if response_id == Gtk.ResponseType.OK:
            date = calendar.get_date()
            year = date.get_year()
            month = date.get_month() # Gtk.Calendar months are 0-based
            day = date.get_day_of_month()
            self.selected_date = f"{year:04d}-{month:02d}-{day:02d}"
            self.date_label.set_text(f"選擇的日期: {self.selected_date}")
        dialog.close()
        
    def run_scripts(self, button):
        if not hasattr(self, "selected_date"):
            self.output_buffer.set_text("請選擇日期。")
            return
        
        self.progress_bar.set_fraction(0.0)
        self.progress_bar.set_text("正在執行...")
        self.output_buffer.set_text("開始備份...\n")
        
        script_dir = os.path.dirname(os.path.abspath(__file__))
        script1 = os.path.join(script_dir, "zip_modified_db_files.sh")
        script2 = os.path.join(script_dir, "zip_modified_source_files.sh")
        script3 = os.path.join(script_dir, "zip_Data_files.sh")
        
        # Start the scripts in a new thread
        thread = Thread(target=self.execute_scripts, args=(script1, script2, script3))
        thread.daemon = True
        thread.start()
    
    def execute_scripts(self, script1, script2, script3):
        try:
            # Run each script with real-time output
            self.run_script_with_output(script1, "資料庫備份", 0.0, 0.3)
            self.run_script_with_output(script2, "資料壓縮", 0.3, 0.65)
            self.run_script_with_output(script3, "備份上傳", 0.65, 1.0)
            
            GLib.idle_add(self.update_progress, 1.0, "🎉 備份完成！")
        except Exception as e:
            GLib.idle_add(self.append_output, f"❌ 發生錯誤: {str(e)}\n")
            GLib.idle_add(self.update_progress, 0.0, "❌ 失敗")
        
        GLib.timeout_add(5000, self.reset_progress_bar)
    
    def run_script_with_output(self, script, description, start_progress, end_progress):
        GLib.idle_add(self.append_output, f"▶️ 開始 {description}...\n")
        GLib.idle_add(self.smooth_progress, start_progress, end_progress)
        
        process = subprocess.Popen(["bash", script, self.selected_date],
                                 stdout=subprocess.PIPE,
                                 stderr=subprocess.PIPE,
                                 text=True,
                                 bufsize=1,
                                 universal_newlines=True)
        
        # Read output in real-time
        while True:
            output = process.stdout.readline()
            if output == '' and process.poll() is not None:
                break
            if output:
                GLib.idle_add(self.append_output, output)
        
        # Get any remaining output
        remaining_output, errors = process.communicate()
        if remaining_output:
            GLib.idle_add(self.append_output, remaining_output)
        if errors:
            GLib.idle_add(self.append_output, f"⚠️ 錯誤: {errors}\n")
        
        GLib.idle_add(self.append_output, f"✅ {description}完成 (返回代碼: {process.returncode})\n\n")

    def append_output(self, text):
        end_iter = self.output_buffer.get_end_iter()
        self.output_buffer.insert(end_iter, text)
        
        # Auto-scroll to the end
        mark = self.output_buffer.create_mark(None, end_iter, True)
        self.output_view.scroll_to_mark(mark, 0.0, True, 0.0, 1.0)

    def smooth_progress(self, start, end, delay=100):
        """讓 ProgressBar 在 start ~ end 之間平滑過渡"""
        step = (end - start) / 10.0
        progress = start

        def update():
            nonlocal progress
            if progress >= end:
                return False
            progress += step
            GLib.idle_add(self.update_progress, progress)
            return True
    
        GLib.timeout_add(delay, update)

    def update_progress(self, fraction, text=None):
        self.progress_bar.set_fraction(fraction)
        if text:
            self.progress_bar.set_text(text)
    
    def reset_progress_bar(self):
        self.progress_bar.set_fraction(0.0)
        self.progress_bar.set_text("")
        return False

class BashRunnerApp(Gtk.Application):
    def __init__(self):
        super().__init__(application_id="com.example.bashrunner")

    def do_activate(self):
        win = BashScriptRunner(self)
        win.present()

app = BashRunnerApp()
app.run(None)
