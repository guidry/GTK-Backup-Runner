#!/bin/bash

# Check if the user has passed a date as an argument; if not, use today's date
if [ -z "$1" ]; then
  DATE=$(date +'%Y-%m-%d')  # Get today's date
else
  DATE="$1"  # Use the supplied date argument
fi

# Get current year and month
CURRENT_YEAR=$(date +'%Y')
CURRENT_MONTH=$(date +'%m')

# Calculate the school year for the directory based on the current date
if [ "$CURRENT_MONTH" -ge 8 ]; then
  YEAR_DIFF=$((CURRENT_YEAR - 1911))
else
  YEAR_DIFF=$((CURRENT_YEAR - 1912))
fi

# Define the source directory dynamically
SOURCE_DIR="/DATA/公務/${YEAR_DIFF}出納"

# Check if the source directory exists, if not create it
if [ ! -d "$SOURCE_DIR" ]; then
  echo "Source directory does not exist. Creating $SOURCE_DIR..."
  mkdir -p "$SOURCE_DIR"
fi

# Get the system's default Downloads folder dynamically
DEST_DIR=$(xdg-user-dir DOWNLOAD)

# Check if xdg-user-dir failed to return a valid directory, fall back to ~/Downloads
if [ -z "$DEST_DIR" ]; then
  DEST_DIR="$HOME/Downloads"
fi
# Check if the destination directory exists, and create it if not
if [ ! -d "$DEST_DIR" ]; then
  echo "Destination directory does not exist. Creating $DEST_DIR..."
  mkdir -p "$DEST_DIR"
fi

# Define the name of the zip file
ZIP_FILE="$DEST_DIR/modified_DATA_files_$(date +'%Y%m%d').zip"

# Create the zip file, including only files modified **on or after** the specified date, and excluding useless files
find "$SOURCE_DIR" -type f -newermt "$DATE" \
  ! -name "*Zone.Identifier*" \
  ! -name "*.~lock.*" \
  ! -name "*.tmp" \
  ! -name "*.bak" \
  ! -name "*.swp" \
  ! -name "*.log" \
  ! -name "*~" \
  ! -name ".*" | zip "$ZIP_FILE" -@
echo "Files in $SOURCE_DIR modified on and after $DATE have been backed up (excluding useless files)."
echo "Zip file created: $ZIP_FILE"

