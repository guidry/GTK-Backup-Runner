import gi
import subprocess
import os
import fnmatch
import time
from threading import Thread
import queue
from datetime import datetime
from pathlib import Path
gi.require_version("Gtk", "4.0")
gi.require_version("Gdk", "4.0")
from gi.repository import Gtk, Gio, Gdk, GLib
import zipfile
import shutil
import configparser
import json
import math
import gettext
import locale

# Set up internationalization
LOCALE_DIR = os.path.join(os.path.dirname(__file__), 'locale')
locale.bindtextdomain('backup_app', LOCALE_DIR)
gettext.bindtextdomain('backup_app', LOCALE_DIR)
gettext.textdomain('backup_app')
_ = gettext.gettext

class BackupApp(Gtk.ApplicationWindow):
    def __init__(self, app):
        super().__init__(application=app, title=_("File Backup Helper"))        
        self.apply_consistent_styling(self)
        self.set_default_size(600, 500)      
 
        # Configuration
        self.config_dir = os.path.join(os.path.expanduser("~"), ".config")
        self.config_path = os.path.join(self.config_dir, "xu-backup-runner.conf")
        self.phases = {}
        self.load_config()
        
        # Language settings
        self.current_language = "en"
        self.languages = {
            "en": "English",
            "zh_TW": "繁體中文",
            "ja": "日本語",
            "ko": "한국어",
            "es": "Español",
            "fr": "Français",
            "de": "Deutsch"
        }
        
        # Main vertical box
        vbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        vbox.set_margin_top(20)
        vbox.set_margin_bottom(20)
        vbox.set_margin_start(20)
        vbox.set_margin_end(20)
        
        # Language selection
        lang_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        lang_label = Gtk.Label(label=_("Language:"))
        self.lang_combo = Gtk.ComboBoxText()
        for code, name in self.languages.items():
            self.lang_combo.append(code, name)
        self.lang_combo.set_active_id(self.current_language)
        self.lang_combo.connect("changed", self.on_language_changed)
        lang_box.append(lang_label)
        lang_box.append(self.lang_combo)
        vbox.append(lang_box)
        
        # Title label
        title_label = Gtk.Label(label=_("File Backup Helper - Backup multiple directories based on configuration"))
        vbox.append(title_label)
        
        # Setup button
        setup_button = Gtk.Button(label=_("Configure Backup Tasks"))
        setup_button.connect("clicked", self.show_setup_dialog)
        vbox.append(setup_button)
        
        # Date picker button
        self.date_button = Gtk.Button(label=_("Select Modified Files Start Date"))
        self.date_button.connect("clicked", self.open_date_picker)
        vbox.append(self.date_button)
        
        # Selected date display
        self.date_label = Gtk.Label(label=_("Selected date: None"))
        vbox.append(self.date_label)
        
        # Backup button
        self.backup_button = Gtk.Button(label=_("Run Backup"))
        self.backup_button.connect("clicked", self.run_backup)
        vbox.append(self.backup_button)
        
        # Progress bar
        self.progress_bar = Gtk.ProgressBar()
        vbox.append(self.progress_bar)
        
        # Output console
        self.output_view = Gtk.TextView()
        self.output_view.set_editable(False)
        self.output_view.set_wrap_mode(Gtk.WrapMode.WORD)
        self.output_buffer = self.output_view.get_buffer()
        
        scroll = Gtk.ScrolledWindow()
        scroll.set_child(self.output_view)
        scroll.set_min_content_height(200)
        vbox.append(scroll)
        
        self.set_child(vbox)
        
        # Progress tracking
        self.progress_queue = queue.Queue()
        self.progress_updater_running = False
        self.total_files = 0
        self.processed_files = 0
        self.current_phase = ""

    def on_language_changed(self, combo):
        """Handle language change"""
        new_lang = combo.get_active_id()
        if new_lang != self.current_language:
            self.current_language = new_lang
            locale.setlocale(locale.LC_ALL, f"{new_lang}.UTF-8")
            # Restart the app to apply language changes
            self.get_application().quit()
            subprocess.Popen(["python3", __file__])

    def load_config(self):
        """Load configuration from file"""
        if not os.path.exists(self.config_path):
            self.phases = {
                "example": {
                    "name": _("Example Backup"),
                    "source": "~/Documents",
                    "target": "~/Downloads",
                    "file_patterns": "*",
                    "exclude_patterns": ""
                }
            }
            self.save_config()
            return
        
        config = configparser.ConfigParser()
        config.read(self.config_path)
        
        self.phases = {}
        for section in config.sections():
            self.phases[section] = {
                "name": config.get(section, "name", fallback=section),
                "source": config.get(section, "source"),
                "target": config.get(section, "target", fallback=""),
                "file_patterns": config.get(section, "file_patterns", fallback="*"),
                "exclude_patterns": config.get(section, "exclude_patterns", fallback="")
            }

    def remove_phase(self, frame, phase_id):
        """Remove a backup phase from both UI and configuration"""
        if phase_id in self.phases:
            del self.phases[phase_id]
        self.phases_container.remove(frame)
        self.phases_container.queue_draw()

    def add_new_phase_ui(self, button):
        """Add UI for a new phase"""
        phase_id = f"phase_{len(self.phases) + 1}"
        self.phases[phase_id] = {
            "name": _("New Backup Phase"),
            "source": "",
            "target": "",
            "file_patterns": "*",
            "exclude_patterns": ""
        }
        self.add_phase_ui(phase_id, self.phases[phase_id])

    def save_config_from_dialog(self, dialog):
        """Save configuration from dialog inputs"""
        for phase_id, phase in list(self.phases.items()):
            if "ui" in phase:
                phase["name"] = phase["ui"]["name"].get_text()
                phase["source"] = phase["ui"]["source"].get_text()
                phase["target"] = phase["ui"]["target"].get_text()
                phase["file_patterns"] = phase["ui"]["patterns"].get_text()
                phase["exclude_patterns"] = phase["ui"]["exclude"].get_text()
                
                del phase["ui"]
                
                if not phase["name"] and not phase["source"]:
                    del self.phases[phase_id]
        
        self.save_config()
        dialog.close()
        self.append_output(_("Configuration saved\n"))

    def save_config(self):
        """Save configuration to file"""
        os.makedirs(self.config_dir, exist_ok=True)
        
        config = configparser.ConfigParser()
        
        for phase_id, phase in self.phases.items():
            clean_id = phase["name"].strip().replace(" ", "_")
            if not clean_id:
                clean_id = f"phase_{phase_id}"
            
            config[clean_id] = {
                "name": phase["name"],
                "source": phase["source"],
                "target": phase["target"],
                "file_patterns": phase["file_patterns"],
                "exclude_patterns": phase["exclude_patterns"]
            }
        
        with open(self.config_path, 'w', encoding='utf-8') as configfile:
            config.write(configfile)

    def select_directory(self, entry_widget):
        """Modern GTK4 directory selection with proper async handling"""
        dialog = Gtk.FileDialog(
            title=_("Select Directory"),
            modal=True
        )
        
        current_path = entry_widget.get_text()
        if current_path and os.path.exists(current_path):
            dialog.set_initial_folder(Gio.File.new_for_path(current_path))
        
        def on_finish(dialog, result):
            try:
                file = dialog.select_folder_finish(result)
                if file:
                    entry_widget.set_text(file.get_path())
            except GLib.Error as err:
                print(f"Error selecting folder: {err}")
        
        dialog.select_folder(
            parent=self,
            cancellable=None,
            callback=on_finish
        )

    def show_setup_dialog(self, button):
        """Show the backup configuration dialog"""
        dialog = Gtk.Dialog(transient_for=self, modal=True)                
        self.apply_consistent_styling(dialog)
        dialog.set_title(_("Configure Backup Tasks"))
        dialog.set_default_size(700, 650)
        
        header = Gtk.HeaderBar()
        dialog.set_titlebar(header)
        
        cancel_btn = Gtk.Button(label=_("Cancel"))
        cancel_btn.connect("clicked", lambda *_: dialog.close())
        header.pack_start(cancel_btn)
        
        save_btn = Gtk.Button(label=_("Save Settings"))
        save_btn.add_css_class("suggested-action")
        save_btn.connect("clicked", lambda b: self.save_config_from_dialog(dialog))
        header.pack_end(save_btn)
        
        new_btn = Gtk.Button(label=_("Add Phase"))
        new_btn.connect("clicked", self.add_new_phase_ui)
        header.pack_end(new_btn)
        
        main_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        main_box.set_margin_top(10)
        main_box.set_margin_bottom(10)
        main_box.set_margin_start(10)
        main_box.set_margin_end(10)
        
        scrolled = Gtk.ScrolledWindow()
        scrolled.set_min_content_height(550)
        scrolled.set_policy(
            Gtk.PolicyType.NEVER,
            Gtk.PolicyType.AUTOMATIC
        )
        
        css_provider = Gtk.CssProvider()
        css_provider.load_from_data(b"""
            scrolledwindow {
                border: 1px solid #ddd;
                border-radius: 5px;
                background: #000;
            }
            .phase-frame {
                min-height: 300px;
                border-radius: 8px;
                border: 1px solid #aaa;
                background: #444;
                padding: 15px;
                margin: 10px;
            }
            .destructive-btn {
                background: #a00;
                color: #eef;
                margin-top: 15px;
            }
        """)
        
        display = Gdk.Display.get_default()
        Gtk.StyleContext.add_provider_for_display(
            display,
            css_provider,
            Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION
        )
        
        self.phases_container = Gtk.Box(
            orientation=Gtk.Orientation.VERTICAL,
            spacing=15,
            hexpand=True,
            vexpand=True
        )
        self.phases_container.set_margin_top(10)
        self.phases_container.set_margin_bottom(10)
        self.phases_container.set_margin_start(10)
        self.phases_container.set_margin_end(10)
        
        for phase_id, phase in self.phases.items():
            self.add_phase_ui(phase_id, phase)
        
        scrolled.set_child(self.phases_container)
        main_box.append(scrolled)
        dialog.set_child(main_box)
        dialog.present()

    def add_phase_ui(self, phase_id, phase):
        """Add UI controls for a backup phase"""
        frame = Gtk.Frame()
        frame.add_css_class("phase-frame")
        
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        box.set_margin_top(10)
        box.set_margin_bottom(10)
        box.set_margin_start(10)
        box.set_margin_end(10)
        
        # Phase name
        name_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        name_label = Gtk.Label(label=_("Phase Name:"), width_request=100, xalign=0)
        name_entry = Gtk.Entry()
        name_entry.set_text(phase["name"])
        name_entry.set_hexpand(True)
        name_entry.set_size_request(-1, 40)
        name_box.append(name_label)
        name_box.append(name_entry)
        box.append(name_box)

        # Source directory
        source_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        source_label = Gtk.Label(label=_("Source Directory:"), width_request=100, xalign=0)
        source_entry = Gtk.Entry()
        source_entry.set_text(phase["source"])
        source_entry.set_hexpand(True)
        source_entry.set_size_request(-1, 40)
        source_button = Gtk.Button(label=_("Browse..."))
        source_button.set_size_request(90, 40)
        source_button.connect("clicked", lambda b, e=source_entry: self.select_directory(e))
        source_box.append(source_label)
        source_box.append(source_entry)
        source_box.append(source_button)
        box.append(source_box)

        # Target directory
        target_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        target_label = Gtk.Label(label=_("Target Directory:"), width_request=100, xalign=0)
        target_entry = Gtk.Entry()
        target_entry.set_text(phase["target"])
        target_entry.set_hexpand(True)
        target_entry.set_size_request(-1, 40)
        target_button = Gtk.Button(label=_("Browse..."))
        target_button.set_size_request(90, 40)
        target_button.connect("clicked", lambda b, e=target_entry: self.select_directory(e))
        target_box.append(target_label)
        target_box.append(target_entry)
        target_box.append(target_button)
        box.append(target_box)

        # File patterns
        patterns_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        patterns_label = Gtk.Label(label=_("File Patterns:"), width_request=100, xalign=0)
        patterns_entry = Gtk.Entry()
        patterns_entry.set_text(phase["file_patterns"])
        patterns_entry.set_hexpand(True)
        patterns_entry.set_size_request(-1, 40)
        patterns_label_tip = Gtk.Label(label=_("(e.g., *.php,*.js,*.css)"))
        patterns_box.append(patterns_label)
        patterns_box.append(patterns_entry)
        patterns_box.append(patterns_label_tip)
        box.append(patterns_box)

        # Exclude patterns
        exclude_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        exclude_label = Gtk.Label(label=_("Exclude Patterns:"), width_request=100, xalign=0)
        exclude_entry = Gtk.Entry()
        exclude_entry.set_text(phase["exclude_patterns"])
        exclude_entry.set_hexpand(True)
        exclude_entry.set_size_request(-1, 40)
        exclude_label_tip = Gtk.Label(label=_("(e.g., *.tmp,*.bak,*.log)"))
        exclude_box.append(exclude_label)
        exclude_box.append(exclude_entry)
        exclude_box.append(exclude_label_tip)
        box.append(exclude_box)

        # Remove button
        remove_button = Gtk.Button(label=_("Remove Phase"))
        remove_button.set_size_request(-1, 40)
        remove_button.add_css_class("destructive-btn")
        remove_button.connect("clicked", lambda b, f=frame, pid=phase_id: self.remove_phase(f, pid))
        box.append(remove_button)

        frame.set_child(box)
        self.phases_container.append(frame)
        
        self.phases[phase_id]["ui"] = {
            "name": name_entry,
            "source": source_entry,
            "target": target_entry,
            "patterns": patterns_entry,
            "exclude": exclude_entry
        }

    def apply_consistent_styling(self, widget):
        """Apply consistent CSS styling"""
        css_provider = Gtk.CssProvider()
        
        css = """
            window, dialog {
                background-color: @theme_bg_color;
                color: @theme_fg_color;
                font-family: 'Noto Sans', Sans;
                font-size: 12pt;
            }
            
            entry {
                min-height: 24px;
                padding: 6px 12px;
                border-radius: 4px;
            }
            
            button {
                min-height: 24px;
                padding: 6px 12px;
                border-radius: 4px;
            }
            
            frame.phase-frame {
                background-color: shade(@theme_bg_color, 0.95);
                border-radius: 8px;
                border: 1px solid @borders;
                padding: 15px;
                margin: 10px;
            }
            
            button.destructive {
                background: @error_bg_color;
                color: @theme_fg_color;
            }
        """
        
        css_provider.load_from_data(css.encode())
        
        display = Gdk.Display.get_default()
        Gtk.StyleContext.add_provider_for_display(
            display,
            css_provider,
            Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION
        )
        
        if hasattr(widget, 'add_css_provider'):
            widget.add_css_provider(css_provider)

    def execute_backup(self):
        """Main backup execution method"""
        try:
            self.append_output(_("Starting file scan...\n"))
            self.count_all_files()
            
            if self.total_files == 0:
                self.progress_queue.put(('error', _("❌ No files found to backup")))
                return
            
            self.append_output(_("Found {0} files to backup\n").format(self.total_files))
            
            for phase_id, phase in self.phases.items():
                self.current_phase = phase_id
                self.phases[phase_id]["processed_in_phase"] = 0
                self.append_output(_("\n🚩️Preparing {0} backup...\n").format(phase['name']))
                self.execute_phase(phase_id)
            
            self.progress_queue.put(('complete', _("🎉 Backup completed!")))
            self.progress_queue.put(('progress', 1.0))
        except Exception as e:
            self.progress_queue.put(('error', _("❌ Error occurred: {0}").format(str(e))))
            import traceback
            self.append_output(traceback.format_exc())

    def count_files(self, phase_id, phase):
        """Count files matching criteria in directory"""
        try:
            phase_cfg = self.phases[phase_id]
            expanded_dir = os.path.expanduser(phase_cfg["source"])
            
            if not os.path.exists(expanded_dir):
                self.append_output(_("⚠️ Source directory {0} doesn't exist, using default documents directory\n").format(expanded_dir))
                return 0
                
            count = 0
            selected_date = datetime.strptime(self.selected_date, "%Y-%m-%d")
            patterns = [p.strip() for p in phase_cfg["file_patterns"].split(",")]
            exclude_patterns = [p.strip() for p in phase_cfg["exclude_patterns"].split(",")]

            self.append_output(_("\nScanning {0} files...\n").format(phase_cfg['name']))
            self.append_output(_("Directory: {0}\n").format(expanded_dir))
            self.append_output(_("File patterns: {0}\n").format(patterns))
            self.append_output(_("Exclude patterns: {0}\n").format(exclude_patterns))

            for root, _, files in os.walk(expanded_dir):
                for file in files:
                    file_path = Path(root) / file
                    try:
                        file_mtime = datetime.fromtimestamp(file_path.stat().st_mtime)
                        if file_mtime >= selected_date:
                            if self.file_matches_criteria(file_path, phase_cfg, False):
                                count += 1
                    except Exception as e:
                        self.append_output("")
            
            self.append_output(_("Found {0} {1} files\n").format(count, phase_cfg['name']))
            return count
                
        except Exception as e:
            self.append_output(_("⚠️ Error counting {0} files: {1}\n").format(phase_cfg['name'], str(e)))
            return 0

    def file_matches_criteria(self, file_path, phase, show_output=True):
        """File pattern matching with universal exclude patterns"""
        filename = file_path.name.lower()
        
        user_include = [p.strip().lower() for p in phase["file_patterns"].split(",") if p.strip()]
        user_exclude = [p.strip().lower() for p in phase["exclude_patterns"].split(",") if p.strip()]
        
        universal_exclude = [
            '*.tmp', '*.temp', '*.bak', '*.backup',
            '*.swp', '~*', '*.~*', '*.log', '*.cache',
            '*.DS_Store', 'Thumbs.db', '*Zone.Identifier*',
            '*.part', '*.download', '*.crdownload',
            '*.pid', '*.lock', '*.lck', '*.aria2',
            '*.synctex.gz', '*.aux', '*.toc'
        ]
        
        if user_include and "*" not in user_include:
            for pattern in user_include:
                if fnmatch.fnmatch(filename, pattern):
                    return True
            return False

        all_excludes = user_exclude + universal_exclude
        for pattern in all_excludes:
            if fnmatch.fnmatch(filename, pattern):
                if pattern in universal_exclude and show_output and pattern not in user_exclude:
                    self.append_output(_("× Excluded system file: {0}\n").format(filename))
                return False

        return True

    def open_date_picker(self, button):
        """Open calendar dialog for date selection"""
        dialog = Gtk.Dialog(transient_for=self, modal=True)
        dialog.set_title(_("Select Date"))
        
        header = Gtk.HeaderBar()
        dialog.set_titlebar(header)
        
        cancel_btn = Gtk.Button(label=_("Cancel"))
        cancel_btn.connect("clicked", lambda *_: dialog.close())
        header.pack_start(cancel_btn)
        
        confirm_btn = Gtk.Button(label=_("Confirm"))
        confirm_btn.add_css_class("suggested-action")
        confirm_btn.connect("clicked", self.on_date_selected, dialog)
        header.pack_end(confirm_btn)
        
        calendar = Gtk.Calendar()
        dialog.set_child(calendar)
        
        dialog.present()

    def on_date_selected(self, button, dialog):
        """Handle date selection from calendar"""
        calendar = dialog.get_child()
        date = calendar.get_date()
        self.selected_date = f"{date.get_year():04d}-{date.get_month():02d}-{date.get_day_of_month():02d}"
        self.date_label.set_text(_("Selected backup start date: {0}").format(self.selected_date))
        dialog.close()

    def run_backup(self, button):
        """Initiate backup process"""
        if not hasattr(self, "selected_date"):
            self.append_output(_("Please select a date to backup files modified since that date.\n"))
            return
        
        self.progress_bar.set_fraction(0.0)
        self.progress_bar.set_text(_("Preparing..."))
        self.output_buffer.set_text(_("Starting backup...\n"))
        self.total_files = 0
        self.processed_files = 0
        
        for phase in self.phases.values():
            phase["completed"] = 0.0
            phase["file_count"] = 0
            phase["processed_in_phase"] = 0
            phase["weight"] = 0.0
        
        if not self.progress_updater_running:
            GLib.timeout_add(100, self.update_progress_from_queue)
            self.progress_updater_running = True
        
        Thread(target=self.execute_backup, daemon=True).start()

    def execute_phase(self, phase_id):
        """Execute backup phase with progress tracking"""
        phase = self.phases[phase_id]
        self.progress_queue.put(('phase_start', (phase_id, phase["name"])))
        self.append_output(_("\n🚀️ Starting {0} backup...\n").format(phase['name']))

        try:
            source_dir = os.path.expanduser(phase["source"]) if phase["source"] else self.get_documents_dir()
            target_dir = os.path.expanduser(phase["target"]) if phase["target"] else self.get_download_dir()
            phase["source"] = source_dir
            phase["target"] = target_dir
            os.makedirs(target_dir, exist_ok=True)

            selected_date = datetime.strptime(self.selected_date, "%Y-%m-%d")
            selected_date_short_string = selected_date.strftime('%Y%m%d')
            zip_filename = f"{phase['name']}_{time.strftime('%Y%m%d')}_modified_since_{selected_date_short_string}.zip"
            zip_path = os.path.join(target_dir, zip_filename)

            processed_files = 0
            total_files = max(phase["file_count"], 1)

            with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
                for root, _, files in os.walk(source_dir):
                    for file in files:
                        file_path = Path(root) / file
                        try:
                            file_mtime = datetime.fromtimestamp(file_path.stat().st_mtime)
                            if file_mtime >= selected_date and self.file_matches_criteria(file_path, phase):
                                rel_path = os.path.relpath(file_path, os.path.dirname(source_dir))
                                zipf.write(file_path, rel_path)
                                processed_files += 1
                                phase["processed_in_phase"] = processed_files

                                phase_progress = processed_files / total_files
                                total_weight = sum(p["weight"] for p in self.phases.values())
                                current_weight = phase["weight"] / total_weight
                                overall_progress = sum(
                                    p["weight"] * (p["processed_in_phase"] / max(p["file_count"], 1))
                                    for p in self.phases.values()
                                ) / total_weight

                                self.append_output(
                                    _("✓ {0}/{1} {2}\n").format(processed_files, total_files, rel_path) +
                                    _("  {0} phase progress: {1}% ").format(phase['name'], math.floor(phase_progress*100)) +                               
                                    _("  Total progress: {0}%\n").format(math.floor(overall_progress*100))
                                )

                                self.progress_queue.put(('progress', min(overall_progress, 0.99)))

                        except Exception as e:
                            self.append_output(_("⚠️ Skipped: {0} ({1})\n").format(file_path, str(e)))

            phase["processed_in_phase"] = processed_files
            self.append_output(_("✅ {0} completed {1} files, created zip at {2}\n").format(
                phase['name'], processed_files, phase['target']))
        except Exception as e:
            self.append_output(_("❌ {0} failed: {1}\n").format(phase['name'], str(e)))
            self.progress_queue.put(('error', _("{0} backup failed").format(phase['name'])))

    def count_all_files(self):
        """Count files and calculate proper weights"""
        total_files = 0
        
        for phase_id, phase in self.phases.items():
            count = self.count_files(phase_id, phase)
            self.phases[phase_id]["file_count"] = count
            total_files += count
        
        for phase_id, phase in self.phases.items():
            phase["weight"] = phase["file_count"] / max(total_files, 1)
        
        self.total_files = total_files
        self.append_output(_("Total {0} files to backup\n").format(self.total_files))

    def get_download_dir(self):
        """Get system download directory"""
        try:
            result = subprocess.run(['xdg-user-dir', 'DOWNLOAD'], 
                                  capture_output=True, 
                                  text=True)
            dest_dir = result.stdout.strip()
            if not dest_dir or not os.path.exists(dest_dir):
                dest_dir = os.path.expanduser("~/Downloads")
            
            os.makedirs(dest_dir, exist_ok=True)
            return dest_dir
        except:
            return os.path.expanduser("~/Downloads")

    def get_documents_dir(self):
        """Get system documents directory"""
        try:
            result = subprocess.run(['xdg-user-dir', 'DOCUMENTS'], 
                                  capture_output=True, 
                                  text=True)
            dest_dir = result.stdout.strip()
            if not dest_dir or not os.path.exists(dest_dir):
                dest_dir = os.path.expanduser("~/Documents")
            
            os.makedirs(dest_dir, exist_ok=True)
            return dest_dir
        except:
            return os.path.expanduser("~/Documents")

    def update_progress_from_queue(self):
        """Process messages from backup thread"""
        try:
            while True:
                item = self.progress_queue.get_nowait()
                
                if item[0] == 'progress':
                    GLib.idle_add(self.progress_bar.set_fraction, item[1])
                    current_phase = self.phases[self.current_phase]
                    phase_progress = sum(
                        p["weight"] * p["completed"] 
                        for p in self.phases.values()
                    )
                    GLib.idle_add(
                        self.progress_bar.set_text, 
                        _("{0}% - {1} ({2}/{3})").format(
                            int(phase_progress*100),
                            current_phase['name'],
                            current_phase['processed_in_phase'],
                            current_phase['file_count'])
                    )
                elif item[0] == 'output':
                    self.append_output(item[1])
                elif item[0] == 'phase_start':
                    GLib.idle_add(
                        self.progress_bar.set_text, 
                        _("Processing {0}...").format(item[1][1])
                    )
                elif item[0] == 'complete':
                    GLib.idle_add(self.progress_bar.set_fraction, 1.0)
                    GLib.idle_add(self.progress_bar.set_text, _("Completed"))
                    self.append_output(f"\n{item[1]}\n")
                elif item[0] == 'error':
                    self.append_output(f"\n{item[1]}\n")
                    GLib.idle_add(self.progress_bar.set_text, "❌ " + _("Failed"))
                    GLib.timeout_add(5000, self.reset_progress_bar)
                    
        except queue.Empty:
            pass
        
        return True

    def append_output(self, text):
        """Add text to output console with auto-scroll"""
        def _append():
            end_iter = self.output_buffer.get_end_iter()
            self.output_buffer.insert(end_iter, text)
            
            mark = self.output_buffer.create_mark(None, end_iter, True)
            self.output_view.scroll_to_mark(mark, 0.0, True, 0.0, 1.0)
        
        GLib.idle_add(_append)
    
    def reset_progress_bar(self):
        """Reset progress bar after completion"""
        self.progress_bar.set_fraction(0.0)
        self.progress_bar.set_text("")
        self.progress_updater_running = False
        return False


class BackupApplication(Gtk.Application):
    def __init__(self):
        super().__init__(application_id="com.example.xubackuprunner")
       
    def do_activate(self):
        win = BackupApp(self)
        win.present()

if __name__ == "__main__":
    # Initialize locale
    locale.setlocale(locale.LC_ALL, '')
    app = BackupApplication()
    app.run(None)
